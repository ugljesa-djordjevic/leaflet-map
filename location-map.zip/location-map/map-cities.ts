import { DB_CONTAINERS } from "../../utilities/constants";
import { IMapCity } from "../../model/LocationMap";
import { deduplicateCities } from "../../utilities/mapDedup";
import { createMapDeviceStatusHandler } from "./createMapDeviceStatusHandler";

createMapDeviceStatusHandler<IMapCity>({
  name: "map-cities",
  route: "map/cities",
  container: DB_CONTAINERS.CITY_DEVICE_STATUS,
  columns: [
    "id",
    "organizationId",
    "customerNbr",
    "cityName",
    "stateName",
    "stateCode",
    "countryCode",
    "percentAvailable",
    "geoPosition",
  ],
  filters: ["countryCode", "stateCode"],
  dedupe: deduplicateCities,
  errorLog: "Error fetching map cities",
});
