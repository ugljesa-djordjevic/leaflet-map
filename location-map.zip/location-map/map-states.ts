import { DB_CONTAINERS } from "../../utilities/constants";
import { IMapState } from "../../model/LocationMap";
import { deduplicateStates } from "../../utilities/mapDedup";
import { createMapDeviceStatusHandler } from "./createMapDeviceStatusHandler";

createMapDeviceStatusHandler<IMapState>({
  name: "map-states",
  route: "map/states",
  container: DB_CONTAINERS.STATE_DEVICE_STATUS,
  columns: [
    "id",
    "organizationId",
    "customerNbr",
    "stateName",
    "stateCode",
    "countryCode",
    "percentAvailable",
    "geoPosition",
  ],
  filters: ["countryCode"],
  dedupe: deduplicateStates,
  errorLog: "Error fetching map states",
});
