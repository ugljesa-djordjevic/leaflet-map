import { DB_CONTAINERS } from "../../utilities/constants";
import { IMapSite } from "../../model/LocationMap";
import { deduplicateSites } from "../../utilities/mapDedup";
import { createMapDeviceStatusHandler } from "./createMapDeviceStatusHandler";

createMapDeviceStatusHandler<IMapSite>({
  name: "map-sites",
  route: "map/sites",
  container: DB_CONTAINERS.SITE_DEVICE_STATUS,
  columns: [
    "id",
    "organizationId",
    "customerNbr",
    "customerSiteNbr",
    "storeNbr",
    "storeName",
    "cityName",
    "stateName",
    "stateCode",
    "countryCode",
    "siteId",
    "percentAvailable",
    "geoPosition",
  ],
  filters: ["countryCode", "stateCode", "cityName"],
  dedupe: deduplicateSites,
  errorLog: "Error fetching map sites",
});
