import { app } from "@azure/functions";
import { getContainerByName } from "../../utilities/dbHelper";
import { handleError } from "../../utilities/handleError";
import {
  DB_CONTAINERS,
  UNEXPECTED_ERROR_MESSAGE,
} from "../../utilities/constants";
import { IMapCountry } from "../../model/LocationMap";

app.http("map-countries", {
  methods: ["GET"],
  route: "map/countries",
  handler: async (request, context) => {
    const assignedMCNs = context.extraInputs.get("assignedMCNs");

    const query = `
      SELECT
        c.id,
        c.organizationId,
        c.customerNbr,
        c.countryCode,
        c.percentAvailable,
        c.geoPosition
      FROM c
    `;
    // WHERE ARRAY_CONTAINS_ANY(c.organizationIdentifiers, ${assignedMCNs})

    try {
      const container = getContainerByName(DB_CONTAINERS.COUNTRY_DEVICE_STATUS);
      const { resources } = await container.items
        .query<IMapCountry>({ query })
        .fetchAll();

      return {
        status: 200,
        jsonBody: resources,
      };
    } catch (error) {
      console.log("Error fetching map countries", error);
      return handleError(500, UNEXPECTED_ERROR_MESSAGE);
    }
  },
});
