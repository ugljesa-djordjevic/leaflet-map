import { DB_CONTAINERS } from "../../utilities/constants";
import { IMapCountry } from "../../model/LocationMap";
import { deduplicateCountries } from "../../utilities/mapDedup";
import { createMapDeviceStatusHandler } from "./createMapDeviceStatusHandler";

createMapDeviceStatusHandler<IMapCountry>({
  name: "map-countries",
  route: "map/countries",
  container: DB_CONTAINERS.COUNTRY_DEVICE_STATUS,
  columns: ["id", "organizationId", "customerNbr", "countryCode", "percentAvailable", "geoPosition"],
  dedupe: deduplicateCountries,
  errorLog: "Error fetching map countries",
});
