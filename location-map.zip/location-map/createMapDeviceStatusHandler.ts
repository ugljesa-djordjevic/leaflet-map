import { app } from "@azure/functions";
import { getContainerByName } from "../../utilities/dbHelper";
import { handleError } from "../../utilities/handleError";
import { UNEXPECTED_ERROR_MESSAGE } from "../../utilities/constants";

interface MapDeviceStatusHandlerConfig<T> {
  /** Azure Functions registration name. */
  name: string;
  /** HTTP route, e.g. "map/states". */
  route: string;
  /** Target Cosmos container (a `DB_CONTAINERS` value). */
  container: string;
  /** Document fields to SELECT (without the `c.` prefix). */
  columns: string[];
  /** Optional equality filters; each entry is both the query-string key and the document field. */
  filters?: string[];
  /** Removes duplicate documents from the result set. */
  dedupe: (resources: T[]) => T[];
  /** Message logged if the query fails. */
  errorLog: string;
}

/**
 * Registers a GET endpoint that returns map device-status documents from a Cosmos
 * container. The four map levels (countries / states / cities / sites) differ only
 * in their columns, optional equality filters, container and dedupe function, so
 * they all share this handler. Every query requires a defined `geoPosition`.
 */
export const createMapDeviceStatusHandler = <T>(config: MapDeviceStatusHandlerConfig<T>): void => {
  const { name, route, container, columns, filters = [], dedupe, errorLog } = config;

  const selectClause = columns.map((column) => `c.${column}`).join(", ");
  const filterClauses = filters.map((field) => `(IS_NULL(@${field}) OR c.${field} = @${field})`);
  const whereClause = ["IS_DEFINED(c.geoPosition) AND NOT IS_NULL(c.geoPosition)", ...filterClauses].join(
    " AND "
  );
  const query = `SELECT ${selectClause} FROM c WHERE ${whereClause}`;

  app.http(name, {
    methods: ["GET"],
    route,
    handler: async (request) => {
      // Org-scoped filtering (disabled): append
      //   AND ARRAY_CONTAINS_ANY(c.organizationIdentifiers, <assignedMCNs>)
      // using context.extraInputs.get("assignedMCNs") when this is re-enabled.
      const parameters = filters.map((field) => ({
        name: `@${field}`,
        value: request.query.get(field),
      }));

      try {
        const cosmos = getContainerByName(container);
        const { resources } = await cosmos.items
          .query<T>(parameters.length ? { query, parameters } : { query })
          .fetchAll();

        return { status: 200, jsonBody: dedupe(resources) };
      } catch (error) {
        console.log(errorLog, error);
        return handleError(500, UNEXPECTED_ERROR_MESSAGE);
      }
    },
  });
};
