﻿import { useMemo } from 'react';
import { Box, Paper, Typography, useTheme } from '@mui/material';
import { LocationMapAvailabilityWidget } from './LocationMapAvailabilityWidget';
import { LocationMapContainer } from './LocationMapContainer';
import { LocationMapLegend } from './LocationMapLegend';
import { LocationMapBreadcrumb } from './LocationMapBreadcrumb';
import { useMapNavigation } from './hooks/useMapNavigation';
import { useLocationMapData } from './hooks/useLocationMapData';
import { IMapContext } from './MapContext';

export const LocationMap = () => {
  const {
    view,
    selectedCountry,
    selectedState,
    selectedCity,
    mapBounds,
    mapCenter,
    mapZoom,
    page,
    setPage,
    hoveredId,
    setHoveredId,
    breadcrumbs,
    handleCountrySelect,
    handleStateSelect,
    handleCitySelect,
    handleStoreSelect,
  } = useMapNavigation();

  const { countriesWithAvailability, usaStatesWithAvailability, citiesForCountry, storesForCity } =
    useLocationMapData({ selectedCountry, selectedState, selectedCity });

  const theme = useTheme();

  const mapContext = useMemo<IMapContext>(
    () => ({
      view,
      currentZoom: 3, // overridden by LocationMapContainer based on Leaflet zoom events
      hoveredId,
      setHoveredId,
      countriesWithAvailability,
      usaStatesWithAvailability,
      citiesForCountry,
      storesForCity,
      selectedCountry,
      selectedState,
      selectedCity,
      onCountryClick: handleCountrySelect,
      onStateClick: handleStateSelect,
      onCityClick: handleCitySelect,
      onStoreClick: handleStoreSelect,
    }),
    [
      view,
      hoveredId,
      setHoveredId,
      countriesWithAvailability,
      usaStatesWithAvailability,
      citiesForCountry,
      storesForCity,
      selectedCountry,
      selectedState,
      selectedCity,
      handleCountrySelect,
      handleStateSelect,
      handleCitySelect,
      handleStoreSelect,
    ]
  );

  return (
    <Paper
      variant='outlined'
      sx={{
        display: 'flex',
        flexDirection: 'column',
        height: '100%',
        width: '100%',
        p: '16px',
        borderRadius: '8px',
        gap: '8px',
      }}
    >
      <Box sx={{ width: '100%' }}>
        <Typography variant='overline'>ESTATE HEALTH</Typography>
      </Box>
      <Box sx={{ display: 'flex', gap: '16px', height: '100%', width: '100%', minHeight: 0 }}>
        <Box
          sx={{
            flex: 1,
            position: 'relative',
            border: 1,
            borderColor: theme.palette.divider,
            bgcolor: theme.palette.background.paper,
            minWidth: 0,
            minHeight: 0,
            overflow: 'hidden',
          }}
        >
          <LocationMapBreadcrumb breadcrumbs={breadcrumbs} />
          <LocationMapContainer
            mapBounds={mapBounds}
            mapCenter={mapCenter}
            mapZoom={mapZoom}
            context={mapContext}
          />
          <LocationMapLegend />
        </Box>

        <LocationMapAvailabilityWidget
          citiesForCountry={citiesForCountry}
          countriesWithAvailability={countriesWithAvailability}
          usaStatesWithAvailability={usaStatesWithAvailability}
          selectedCity={selectedCity}
          selectedState={selectedState}
          selectedCountry={selectedCountry}
          storesForCity={storesForCity}
          view={view}
          itemsPerPage={10}
          page={page}
          setPage={setPage}
          hoveredId={hoveredId}
          setHoveredId={setHoveredId}
          onCountryClick={handleCountrySelect}
          onStateClick={handleStateSelect}
          onCityClick={handleCitySelect}
          onStoreClick={handleStoreSelect}
        />
      </Box>
    </Paper>
  );
};
