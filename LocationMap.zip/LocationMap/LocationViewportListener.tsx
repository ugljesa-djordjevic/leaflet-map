import { useCallback, useRef } from 'react';
import { useMapEvents } from 'react-leaflet';

export const LocationViewportListener = ({
  onViewportChange,
  onZoomChange,
}: {
  onViewportChange: (bounds: L.LatLngBounds) => void;
  onZoomChange?: (zoom: number) => void;
}) => {
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const updateBounds = useCallback(
    (map: L.Map) => {
      if (debounceRef.current) clearTimeout(debounceRef.current);
      debounceRef.current = setTimeout(() => {
        onViewportChange(map.getBounds());
        onZoomChange?.(map.getZoom());
      }, 120);
    },
    [onViewportChange, onZoomChange]
  );

  useMapEvents({
    moveend: (event) => updateBounds(event.target),
    zoomend: (event) => updateBounds(event.target),
    load: (event) => updateBounds(event.target),
  });

  return null;
};
