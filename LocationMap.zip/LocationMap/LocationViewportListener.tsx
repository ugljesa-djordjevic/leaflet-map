import { useCallback, useRef } from 'react';
import L from 'leaflet';
import { useMapEvents } from 'react-leaflet';
import { VIEWPORT_DEBOUNCE_MS } from './mapConstants';

type Props = {
  onViewportChange: (bounds: L.LatLngBounds) => void;
  onZoomChange?: (zoom: number) => void;
};

/** Reports the map's bounds and zoom after pan/zoom settles (debounced). */
export const LocationViewportListener = ({ onViewportChange, onZoomChange }: Props) => {
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const updateBounds = useCallback(
    (map: L.Map) => {
      if (debounceRef.current) clearTimeout(debounceRef.current);
      debounceRef.current = setTimeout(() => {
        onViewportChange(map.getBounds());
        onZoomChange?.(map.getZoom());
      }, VIEWPORT_DEBOUNCE_MS);
    },
    [onViewportChange, onZoomChange]
  );

  useMapEvents({
    moveend: (event) => updateBounds(event.target),
    zoomend: (event) => updateBounds(event.target),
    load: (event) => updateBounds(event.target),
  });

  return null;
};
