import { Box, Typography } from '@mui/material';
import { LEGEND_GRADIENT, LEGEND_TICKS } from './availability';
import { Z_INDEX } from './mapConstants';

/** Bottom-left legend showing the availability colour scale (0–100%). */
export const LocationMapLegend = () => (
  <Box sx={{ position: 'absolute', bottom: 25, left: 25, zIndex: Z_INDEX.mapOverlay }}>
    <Box sx={{ height: '12px', width: '200px', borderRadius: '20px', background: LEGEND_GRADIENT }} />
    <Box
      sx={{
        display: 'flex',
        justifyContent: 'space-between',
        fontSize: '0.75rem',
        color: 'text.secondary',
        marginTop: '0.25rem',
      }}
    >
      {LEGEND_TICKS.map((tick) => (
        <Typography key={tick} fontSize='small'>
          {tick}
        </Typography>
      ))}
    </Box>
  </Box>
);
