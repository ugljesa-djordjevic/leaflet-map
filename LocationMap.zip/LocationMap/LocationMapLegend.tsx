import { Box, Typography } from '@mui/material';

export const LocationMapLegend = () => {
  return (
    <Box
      sx={{
        position: 'absolute',
        bottom: 25,
        left: 25,
        zIndex: 1000,
      }}
    >
      <Box
        sx={{
          height: '12px',
          width: '200px',
          borderRadius: '20px',
          background: 'linear-gradient(to right, #dc2626, #ea580c, #ca8a04, #84cc16, #22c55e)',
        }}
      />
      <Box
        sx={{
          display: 'flex',
          justifyContent: 'space-between',
          fontSize: '0.75rem',
          color: '#9ca3af',
          marginTop: '0.25rem',
        }}
      >
        <Typography fontSize='small'>0</Typography>
        <Typography fontSize='small'>20</Typography>
        <Typography fontSize='small'>40</Typography>
        <Typography fontSize='small'>60</Typography>
        <Typography fontSize='small'>80</Typography>
        <Typography fontSize='small'>100</Typography>
      </Box>
    </Box>
  );
};
