import { Theme } from '@mui/material';
import { ColorUtils } from 'src/utils/ColorUtils';

/**
 * Single source of truth for how an availability percentage maps to colour and
 * to a status label. Markers, cluster bubbles, the legend gradient and the
 * gauge all derive colour from {@link getAvailabilityColor}; the sidebar status
 * chip is the one place that turns availability into a discrete band.
 */

export interface AvailabilityStatus {
  label: string;
  /** MUI palette path, resolved by the `sx` prop (e.g. `info.subtleContrast`). */
  color: string;
  bgcolor: string;
}

/**
 * Unified availability band scale. Higher availability = lower risk. `min` is
 * the inclusive lower bound; bands are ordered high→low so the first match wins.
 * This is the single definition behind the status chip — adjust bands here.
 */
const CRITICAL_STATUS: AvailabilityStatus = {
  label: 'Critical',
  color: 'error.subtleContrast',
  bgcolor: 'error.subtle',
};

const STATUS_BANDS: ReadonlyArray<{ min: number; status: AvailabilityStatus }> = [
  { min: 70, status: { label: 'Low', color: 'info.subtleContrast', bgcolor: 'info.subtle' } },
  { min: 40, status: { label: 'Medium', color: 'category4.subtleContrast', bgcolor: 'category4.subtle' } },
  { min: 20, status: { label: 'High', color: 'warning.subtleContrast', bgcolor: 'warning.subtle' } },
  { min: 0, status: CRITICAL_STATUS },
];

export const getAvailabilityStatus = (availability: number): AvailabilityStatus =>
  STATUS_BANDS.find((band) => availability >= band.min)?.status ?? CRITICAL_STATUS;

/** Theme-driven colour for an availability value (high = healthy, low = critical). */
export const getAvailabilityColor = (theme: Theme, availability: number): string =>
  ColorUtils.getProgressColor(theme, availability, false);

/**
 * Fixed brand colour used to highlight a hovered marker. Intentionally NOT part
 * of the availability scale and not theme-derived — the design calls for hover to
 * always be this purple. Change it here if the design changes.
 */
export const HOVER_MARKER_COLOR = '#7c3aed';
export const getHoverColor = (): string => HOVER_MARKER_COLOR;

/** Sample points used to build the continuous legend gradient from the theme. */
const LEGEND_GRADIENT_SAMPLES = [0, 25, 50, 75, 100];

export const buildLegendGradient = (theme: Theme): string => {
  const stops = LEGEND_GRADIENT_SAMPLES.map((value) => getAvailabilityColor(theme, value));
  return `linear-gradient(to right, ${stops.join(', ')})`;
};

/** Axis labels rendered beneath the legend gradient. */
export const LEGEND_TICKS = [0, 20, 40, 60, 80, 100];
