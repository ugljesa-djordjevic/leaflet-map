/**
 * Single source of truth for how an availability percentage maps to colour and
 * to a status label. Markers, cluster bubbles and the legend share the fixed
 * red→orange→yellow→green colour scale below; the sidebar status chip turns
 * availability into a discrete band.
 */

export interface AvailabilityStatus {
  label: string;
  /** MUI palette path, resolved by the `sx` prop (e.g. `info.subtleContrast`). */
  color: string;
  bgcolor: string;
}

/**
 * Fixed availability colour scale (red → orange → yellow → lime → green).
 * These are brand colours, intentionally not theme-derived, so the map reads the
 * same regardless of theme. The marker fill is picked from these bands; the
 * legend draws a continuous gradient across them.
 */
export const AVAILABILITY_COLORS = {
  excellent: '#22c55e', // >= 80
  good: '#65a30d', // >= 60
  fair: '#ca8a04', // >= 40
  poor: '#ea580c', // >= 20
  critical: '#dc2626', // < 20
};

/** Theme-independent colour for an availability value (high = healthy, low = critical). */
export const getAvailabilityColor = (availability: number): string => {
  if (availability >= 80) return AVAILABILITY_COLORS.excellent;
  if (availability >= 60) return AVAILABILITY_COLORS.good;
  if (availability >= 40) return AVAILABILITY_COLORS.fair;
  if (availability >= 20) return AVAILABILITY_COLORS.poor;
  return AVAILABILITY_COLORS.critical;
};

/**
 * Fixed brand colour used to highlight a hovered marker. Intentionally NOT part
 * of the availability scale — the design calls for hover to always be this purple.
 */
export const HOVER_MARKER_COLOR = '#7c3aed';
export const getHoverColor = (): string => HOVER_MARKER_COLOR;

const CRITICAL_STATUS: AvailabilityStatus = {
  label: 'Critical',
  color: 'error.subtleContrast',
  bgcolor: 'error.subtle',
};

/**
 * Unified availability band scale for the status chip. Higher availability =
 * lower risk. `min` is the inclusive lower bound; bands are ordered high→low so
 * the first match wins.
 */
const STATUS_BANDS: ReadonlyArray<{ min: number; status: AvailabilityStatus }> = [
  { min: 70, status: { label: 'Low', color: 'info.subtleContrast', bgcolor: 'info.subtle' } },
  { min: 40, status: { label: 'Medium', color: 'category4.subtleContrast', bgcolor: 'category4.subtle' } },
  { min: 20, status: { label: 'High', color: 'warning.subtleContrast', bgcolor: 'warning.subtle' } },
  { min: 0, status: CRITICAL_STATUS },
];

export const getAvailabilityStatus = (availability: number): AvailabilityStatus =>
  STATUS_BANDS.find((band) => availability >= band.min)?.status ?? CRITICAL_STATUS;

/**
 * Continuous gradient (0%→100%, left→right) drawn under the legend. The lime stop
 * (`#84cc16`) is slightly brighter than the marker `good` band by design, giving
 * the gradient a smoother sweep.
 */
export const LEGEND_GRADIENT = `linear-gradient(to right, ${AVAILABILITY_COLORS.critical}, ${AVAILABILITY_COLORS.poor}, ${AVAILABILITY_COLORS.fair}, #84cc16, ${AVAILABILITY_COLORS.excellent})`;

/** Axis labels rendered beneath the legend gradient. */
export const LEGEND_TICKS = [0, 20, 40, 60, 80, 100];
