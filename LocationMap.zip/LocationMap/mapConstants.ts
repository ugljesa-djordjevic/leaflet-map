import { MapView } from './types';

/**
 * All map tuning values live here so the widget has no magic numbers scattered
 * across components. Adjust behaviour from this single file.
 */

/** Initial/world view camera. Center is [latitude, longitude] (Leaflet order). */
export const MAP_DEFAULTS = {
  center: [30, 0] as [number, number],
  zoom: 3,
};

/** Zoom level applied when drilling into each navigation level. */
export const ZOOM_BY_LEVEL = {
  country: 5,
  state: 7,
  city: 13,
  store: 15,
};

/** A marker's label becomes permanently visible once the map zoom reaches this
 *  level for the active view (otherwise the label only shows on hover). */
export const LABEL_ZOOM_BY_VIEW: Record<MapView, number> = {
  world: 4,
  'usa-states': 4,
  country: 5,
  city: 9,
};

/** Pixel diameter of an availability marker. */
export const MARKER_SIZE = {
  base: 32,
  hover: 42,
};

/** Pixel diameter of a cluster bubble. */
export const CLUSTER_SIZE = 46;

/** How far to extend the viewport when culling off-screen markers (fraction of
 *  the visible bounds added on every side). */
export const VIEWPORT_PAD = 0.2;

/** Debounce for map move/zoom events before recomputing the viewport. */
export const VIEWPORT_DEBOUNCE_MS = 120;

/** Options used when fitting the map to a bounding box. */
export const FIT_BOUNDS_OPTIONS = {
  padding: [50, 50] as [number, number],
  maxZoom: 12,
};

/** Maximum number of countries listed in the sidebar at world level. */
export const COUNTRY_LIST_LIMIT = 100;

/** Items shown per page in the sidebar availability list. */
export const SIDEBAR_ITEMS_PER_PAGE = 10;

/** Stacking order for the overlays drawn on top of the Leaflet canvas. */
export const Z_INDEX = {
  mapOverlay: 1000,
  sidebarFooter: 2,
};
