import { useEffect } from 'react';
import { useMap } from 'react-leaflet';

export const LocationMapController = ({
  bounds,
  center,
  zoom,
}: {
  bounds: L.LatLngBounds | null;
  center: [number, number] | null;
  zoom: number | null;
}) => {
  const map = useMap();
  useEffect(() => {
    if (bounds) map.fitBounds(bounds, { padding: [50, 50], maxZoom: 12 });
    else if (center && zoom) map.setView(center, zoom);
  }, [bounds, center, zoom, map]);
  return null;
};
