import { useEffect } from 'react';
import L from 'leaflet';
import { useMap } from 'react-leaflet';
import { FIT_BOUNDS_OPTIONS } from './mapConstants';

type Props = {
  bounds: L.LatLngBounds | null;
  center: [number, number] | null;
  zoom: number | null;
};

/** Imperatively drives the Leaflet camera from the navigation state. */
export const LocationMapController = ({ bounds, center, zoom }: Props) => {
  const map = useMap();

  useEffect(() => {
    if (bounds) map.fitBounds(bounds, FIT_BOUNDS_OPTIONS);
    else if (center && zoom) map.setView(center, zoom);
  }, [bounds, center, zoom, map]);

  return null;
};
