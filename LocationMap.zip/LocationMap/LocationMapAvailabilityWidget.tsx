import { Box, Button, Typography, useTheme } from '@mui/material';
import { HeaderTitle } from 'src/modules/shared/components';
import { CircularProgressWithContent } from '../CircularProgressWithContent';
import { ChevronLeftOutlined, ChevronRightOutlined } from '@mui/icons-material';
import { useMemo } from 'react';
import { LocationMapAvailabilityWidgetItem } from './LocationMapAvailabilityWidgetItem';
import { StoresMarker } from 'src/models';

type Props = {
  view: 'world' | 'country' | 'city' | 'usa-states';
  itemsPerPage: number;
  page: number;
  setPage: React.Dispatch<React.SetStateAction<number>>;
  storesForCity: StoresMarker[];
  citiesForCountry: GeoJSON.Feature[];
  countriesWithAvailability: GeoJSON.Feature[];
  usaStatesWithAvailability: GeoJSON.Feature[];
  selectedCity: GeoJSON.Feature | null;
  selectedState: GeoJSON.Feature | null;
  selectedCountry: GeoJSON.Feature | null;
  hoveredId: string | null;
  setHoveredId: React.Dispatch<React.SetStateAction<string | null>>;
  onCountryClick: (country: GeoJSON.Feature) => void;
  onStateClick: (state: GeoJSON.Feature) => void;
  onCityClick: (city: GeoJSON.Feature) => void;
  onStoreClick: (store: StoresMarker) => void;
};

export const LocationMapAvailabilityWidget = ({
  view,
  itemsPerPage = 10,
  page,
  setPage,
  storesForCity,
  citiesForCountry = [],
  countriesWithAvailability = [],
  usaStatesWithAvailability = [],
  selectedCity,
  selectedState,
  selectedCountry,
  hoveredId,
  setHoveredId,
  onCountryClick,
  onStateClick,
  onCityClick,
  onStoreClick,
}: Props) => {
  const theme = useTheme();

  type WidgetItem = {
    id: string;
    name: string;
    availability: number;
    onClick?: () => void;
    onHoverId?: string;
  };

  const getStatus = (av: number) => {
    if (av >= 70) return { label: 'Low', color: 'info.subtleContrast', bgcolor: 'info.subtle' };
    if (av >= 40)
      return {
        label: 'Medium',
        color: 'categorical.category4.subtleContrast',
        bgcolor: 'categorical.category4.subtle',
      };
    if (av >= 20)
      return { label: 'High', color: 'warning.subtleContrast', bgcolor: 'warning.subtle' };
    return { label: 'Critical', color: 'error.dark', bgcolor: 'error.subtle' };
  };

  const overallAvailability = useMemo(() => {
    if (view === 'city' && storesForCity.length)
      return Math.round(
        storesForCity.reduce((s, x) => s + x.availability, 0) / storesForCity.length
      );
    if (view === 'country' && citiesForCountry.length)
      return Math.round(
        citiesForCountry.reduce(
          (s: number, c: GeoJSON.Feature) => s + c?.properties?.availability,
          0
        ) / citiesForCountry.length
      );
    if (view === 'usa-states' && usaStatesWithAvailability.length)
      return Math.round(
        usaStatesWithAvailability.reduce((s, st) => s + st?.properties?.availability, 0) /
          usaStatesWithAvailability.length
      );
    return 91;
  }, [view, storesForCity, citiesForCountry, usaStatesWithAvailability]);

  const currentTitle = useMemo(() => {
    if (view === 'city' && selectedCity) return selectedCity?.properties?.NAME;
    if (view === 'country' && selectedState) return selectedState?.properties?.name;
    if (view === 'country' && selectedCountry) return selectedCountry?.properties?.NAME;
    if (view === 'usa-states') return 'United States';
    return 'World';
  }, [view, selectedCountry, selectedState, selectedCity]);

  const listItems = useMemo<WidgetItem[]>(() => {
    if (view === 'city')
      return storesForCity.map((s) => ({
        id: s.id,
        name: s.name,
        availability: s.availability,
        onClick: () => onStoreClick(s),
        onHoverId: s.id,
      }));
    if (view === 'usa-states')
      return usaStatesWithAvailability.map((st) => ({
        id: st?.properties?.postal,
        name: st?.properties?.name,
        availability: st?.properties?.availability,
        onClick: () => onStateClick(st as GeoJSON.Feature),
        onHoverId: st?.properties?.postal || st?.properties?.name,
      }));
    if (view === 'country')
      return citiesForCountry.map((c: GeoJSON.Feature) => ({
        id: c.properties?.NAME,
        name: c.properties?.NAME,
        availability: c.properties?.availability,
        onClick: () => onCityClick(c),
        onHoverId: `${c.properties?.ADM0_A3 || c.properties?.ADM0NAME}-${c.properties?.NAME}`,
      }));
    return countriesWithAvailability
      .map((c) => ({
        id: c.properties?.ADM0_A3,
        name: c.properties?.NAME,
        availability: c.properties?.availability,
        onClick: () => onCountryClick(c as GeoJSON.Feature),
        onHoverId: c.properties?.ADM0_A3 || c.properties?.NAME,
      }))
      .slice(0, 100);
  }, [
    view,
    storesForCity,
    citiesForCountry,
    countriesWithAvailability,
    usaStatesWithAvailability,
    onCountryClick,
    onStateClick,
    onCityClick,
    onStoreClick,
  ]);

  const sortedItems = useMemo(
    () => [...listItems].sort((a, b) => a.availability - b.availability),
    [listItems]
  );
  const paginatedItems = useMemo(
    () => sortedItems.slice(page * itemsPerPage, (page + 1) * itemsPerPage),
    [sortedItems, page, itemsPerPage]
  );
  const totalPages = Math.ceil(sortedItems.length / itemsPerPage);

  return (
    <Box
      sx={{
        position: 'relative',
        width: '283px',
        backgroundColor: theme.palette.background.paper,
        border: 1,
        borderColor: theme.palette.divider,
        display: 'flex',
        flexDirection: 'column',
      }}
    >
      <Box sx={{ padding: '0 8px 6px 8px' }}>
        <HeaderTitle title='AVAILABILITY' subTitle={view === 'world' ? 'REGIONS' : currentTitle} />
        <Box sx={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          <CircularProgressWithContent value={overallAvailability} content={''} />
          <Typography variant='display1'>{overallAvailability}%</Typography>
        </Box>
      </Box>

      <Box
        sx={{
          borderTop: 1,
          borderColor: theme.palette.divider,
          borderRadius: '4px',
          flex: 1,
          overflow: 'auto',
        }}
      >
        <Box
          sx={{
            p: '6px 16px',
          }}
        >
          <Typography variant='overline'>OVERALL DEVICE AVAILABILITY</Typography>
        </Box>
        <Box sx={{ pb: '52px' }}>
          {paginatedItems.map((item) => {
            const status = getStatus(item.availability);
            const isHovered = hoveredId === (item.onHoverId ?? item.id);
            return (
              <LocationMapAvailabilityWidgetItem
                key={item.id}
                item={item}
                status={status}
                onClick={item.onClick}
                onMouseEnter={() => setHoveredId(item.onHoverId ?? item.id)}
                onMouseLeave={() => setHoveredId(null)}
                isHovered={isHovered}
              />
            );
          })}
        </Box>

        <Box
          sx={{
            position: 'absolute',
            bottom: '0',
            left: '0',
            right: '0',
            height: '52px',
            pl: '24px',
            pr: '6px',
            borderTop: '1px solid #e5e7eb',
            backgroundColor: theme.palette.background.paper,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-around',
            zIndex: '2',
          }}
        >
          <Typography>
            {page * itemsPerPage + 1}–{Math.min((page + 1) * itemsPerPage, sortedItems.length)} of{' '}
            {sortedItems.length}
          </Typography>
          <Box sx={{ pl: '20px' }}>
            <Button
              onClick={() => setPage((p) => Math.max(0, p - 1))}
              disabled={page === 0}
              sx={{
                '&:hover': { backgroundColor: '#f3f4f6' },
                borderRadius: 1,
                '&.Mui-disabled': { opacity: 0.3 },
              }}
            >
              <ChevronLeftOutlined fontSize='small' />
            </Button>
            <Button
              onClick={() => setPage((p) => Math.min(totalPages - 1, p + 1))}
              disabled={page >= totalPages - 1}
              sx={{
                '&:hover': { backgroundColor: '#f3f4f6' },
                borderRadius: 1,
                '&.Mui-disabled': { opacity: 0.3 },
              }}
            >
              <ChevronRightOutlined fontSize='small' />
            </Button>
          </Box>
        </Box>
      </Box>
    </Box>
  );
};
