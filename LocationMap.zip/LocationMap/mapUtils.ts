import L from 'leaflet';
import { CLUSTER_SIZE, MARKER_SIZE } from './mapConstants';

/**
 * Leaflet `divIcon` factories for availability markers and cluster bubbles.
 * Colours are passed in already resolved from the MUI theme — this module does
 * no colour logic of its own. CSS class names match the widget's external
 * stylesheet and must not be renamed.
 */

/** Lightens a colour toward white by `amount` (0–1). Accepts both hex (#rrggbb) and rgba(...) strings. */
export const lightenColor = (color: string, amount = 0.22): string => {
  let r: number, g: number, b: number;

  const rgbaMatch = color.match(/rgba?\(\s*(\d+),\s*(\d+),\s*(\d+)/);
  if (rgbaMatch) {
    r = Number(rgbaMatch[1]);
    g = Number(rgbaMatch[2]);
    b = Number(rgbaMatch[3]);
  } else {
    const clean = color.replace('#', '');
    if (clean.length !== 6) return color;
    const num = Number.parseInt(clean, 16);
    r = (num >> 16) & 0xff;
    g = (num >> 8) & 0xff;
    b = num & 0xff;
  }

  const tint = (channel: number) => Math.min(255, Math.round(channel + (255 - channel) * amount));
  const toHex = (channel: number) => channel.toString(16).padStart(2, '0');
  return `#${toHex(tint(r))}${toHex(tint(g))}${toHex(tint(b))}`;
};

/** Border colour derived from a marker's fill. */
export const strokeFromFill = (fill: string): string => lightenColor(fill, 0.5);

export const createMarkerIcon = ({
  fill,
  isHovered,
}: {
  fill: string;
  isHovered: boolean;
}): L.DivIcon => {
  const size = isHovered ? MARKER_SIZE.hover : MARKER_SIZE.base;
  const stroke = strokeFromFill(fill);
  return L.divIcon({
    className: 'availability-marker-icon',
    html: `<div class="availability-marker ${isHovered ? 'availability-marker--hover' : ''}" style="background:${fill}; border-color:${stroke}; width:${size}px; height:${size}px;"></div>`,
    iconSize: [size, size],
    iconAnchor: [size / 2, size / 2],
  });
};

/**
 * Builds the cluster icon factory for a `MarkerClusterGroup`. The cluster colour
 * reflects the average availability of its child markers; `resolveColor` maps
 * that average to a theme colour. Each child marker stashes its `availability`
 * on `marker.options` (see `AvailabilityMarker`) so the average can be computed.
 */
export const makeClusterIcon =
  (resolveColor: (availability: number) => string) =>
  (cluster: L.MarkerCluster): L.DivIcon => {
    const markers = cluster.getAllChildMarkers() as L.Marker[];
    const values = markers
      .map((m) => (m.options as { availability?: number }).availability)
      .filter((v): v is number => typeof v === 'number');
    const rounded = values.length
      ? Math.round(values.reduce((a, b) => a + b, 0) / values.length)
      : 0;
    const fill = resolveColor(rounded);
    const stroke = strokeFromFill(fill);
    return L.divIcon({
      className: 'availability-cluster-icon',
      html: `<div class="availability-cluster" style="background:${fill}; border-color:${stroke};"><span class="availability-cluster__value">${rounded}%</span></div>`,
      iconSize: [CLUSTER_SIZE, CLUSTER_SIZE],
      iconAnchor: [CLUSTER_SIZE / 2, CLUSTER_SIZE / 2],
    });
  };
