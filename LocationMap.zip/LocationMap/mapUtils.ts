import L from 'leaflet';

export type MapView = 'world' | 'country' | 'usa-states' | 'city';

export const HOVER_COLOR = '#7c3aed';
export const MARKER_BASE_SIZE = 32;
export const MARKER_HOVER_SIZE = 42;

export const LABEL_THRESHOLD_BY_VIEW: Record<MapView, number> = {
  world: 4,
  'usa-states': 4,
  country: 5,
  city: 9,
};

export const getMarkerColor = (availability: number): string => {
  if (availability >= 80) return '#22c55e';
  if (availability >= 60) return '#65a30d';
  if (availability >= 40) return '#ca8a04';
  if (availability >= 20) return '#ea580c';
  return '#dc2626';
};

export const lightenColor = (hex: string, amount = 0.22): string => {
  const clean = hex.replace('#', '');
  if (clean.length !== 6) return hex;
  const num = parseInt(clean, 16);
  const r = (num >> 16) & 0xff;
  const g = (num >> 8) & 0xff;
  const b = num & 0xff;
  const tint = (channel: number) => Math.min(255, Math.round(channel + (255 - channel) * amount));
  const toHex = (channel: number) => channel.toString(16).padStart(2, '0');
  return `#${toHex(tint(r))}${toHex(tint(g))}${toHex(tint(b))}`;
};

export const strokeFromFill = (fill: string): string => lightenColor(fill, 0.5);

export const createMarkerIcon = ({
  fill,
  isHovered,
}: {
  fill: string;
  isHovered: boolean;
}): L.DivIcon => {
  const size = isHovered ? MARKER_HOVER_SIZE : MARKER_BASE_SIZE;
  const stroke = strokeFromFill(fill);
  return L.divIcon({
    className: 'availability-marker-icon',
    html: `<div class="availability-marker ${isHovered ? 'availability-marker--hover' : ''}" style="background:${fill}; border-color:${stroke}; width:${size}px; height:${size}px;"></div>`,
    iconSize: [size, size],
    iconAnchor: [size / 2, size / 2],
  });
};

export const createClusterIcon = (cluster: L.MarkerCluster): L.DivIcon => {
  const markers = cluster.getAllChildMarkers() as L.Marker[];
  const values = markers
    .map((m) => (m.options as { availability?: number }).availability)
    .filter((v): v is number => typeof v === 'number');
  const rounded = values.length ? Math.round(values.reduce((a, b) => a + b, 0) / values.length) : 0;
  const fill = getMarkerColor(rounded);
  const stroke = strokeFromFill(fill);
  return L.divIcon({
    className: 'availability-cluster-icon',
    html: `<div class="availability-cluster" style="background:${fill}; border-color:${stroke};"><span class="availability-cluster__value">${rounded}%</span></div>`,
    iconSize: [46, 46],
    iconAnchor: [23, 23],
  });
};
