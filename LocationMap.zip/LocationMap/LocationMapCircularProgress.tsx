import { FC } from 'react';
import { Box, Typography, useTheme } from '@mui/material';
import { Gauge, gaugeClasses } from '@mui/x-charts';
import { ColorUtils } from 'src/utils/ColorUtils';

type Props = {
  value: number;
  size?: number;
};

/** Pixels trimmed from the radius to give the gauge ring its thickness. */
const RING_THICKNESS = 4;
const DEFAULT_SIZE = 36;

export const LocationMapCircularProgress: FC<Props> = ({ value, size = DEFAULT_SIZE }) => {
  const theme = useTheme();
  const color = ColorUtils.getProgressColor(theme, value, false);

  return (
    <Box position='relative' display='inline-flex' flexDirection='column' alignItems='center'>
      <Gauge
        text=''
        sx={{
          [`& .${gaugeClasses.valueArc}`]: { fill: color },
          [`& .${gaugeClasses.referenceArc}`]: { fill: theme.palette.primary.subtle },
        }}
        innerRadius={size / 2 - RING_THICKNESS}
        cornerRadius={50}
        margin={0}
        width={size}
        height={size}
        value={value}
      />
      <Typography
        top={0}
        left={0}
        bottom={0}
        right={0}
        position='absolute'
        display='flex'
        alignItems='center'
        justifyContent='center'
        color='text.secondary'
        fontSize='11px'
        fontWeight='500'
      >
        {value}%
      </Typography>
    </Box>
  );
};
