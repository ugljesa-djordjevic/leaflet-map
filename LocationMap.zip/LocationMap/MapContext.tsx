import { createContext, useContext } from 'react';
import { StoresMarker } from 'src/models';
import { MapView } from './mapUtils';

export interface IMapContext {
  view: MapView;
  currentZoom: number;
  hoveredId: string | null;
  setHoveredId: (id: string | null) => void;
  countriesWithAvailability: GeoJSON.Feature[];
  usaStatesWithAvailability: GeoJSON.Feature[];
  citiesForCountry: GeoJSON.Feature[];
  storesForCity: StoresMarker[];
  selectedCountry: GeoJSON.Feature | null;
  selectedState: GeoJSON.Feature | null;
  selectedCity: GeoJSON.Feature | null;
  onCountryClick: (feature: GeoJSON.Feature) => void;
  onStateClick: (feature: GeoJSON.Feature) => void;
  onCityClick: (city: GeoJSON.Feature) => void;
  onStoreClick: (store: StoresMarker) => void;
}

export const MapContext = createContext<IMapContext | null>(null);

export const useMapContext = (): IMapContext => {
  const ctx = useContext(MapContext);
  if (!ctx) throw new Error('useMapContext must be used inside MapContext.Provider');
  return ctx;
};
