import { createContext, useContext } from 'react';
import { StoresMarker } from 'src/models';
import { MapView } from './mapUtils';

/**
 * Stable navigation data – changes only on navigation events, never on hover.
 * Consumers of this context are not re-rendered by hover activity.
 */
export interface IMapDataContext {
  view: MapView;
  currentZoom: number;
  countriesWithAvailability: GeoJSON.Feature[];
  usaStatesWithAvailability: GeoJSON.Feature[];
  citiesForCountry: GeoJSON.Feature[];
  storesForCity: StoresMarker[];
  selectedCountry: GeoJSON.Feature | null;
  selectedState: GeoJSON.Feature | null;
  selectedCity: GeoJSON.Feature | null;
  onCountryClick: (feature: GeoJSON.Feature) => void;
  onStateClick: (feature: GeoJSON.Feature) => void;
  onCityClick: (city: GeoJSON.Feature) => void;
  onStoreClick: (store: StoresMarker) => void;
}

/**
 * High-frequency hover state – isolated so hover changes never trigger re-renders
 * in components that only care about navigation data.
 */
export interface IMapHoverContext {
  hoveredId: string | null;
  setHoveredId: (id: string | null) => void;
}

export const MapDataContext = createContext<IMapDataContext | null>(null);
export const MapHoverContext = createContext<IMapHoverContext | null>(null);

export const useMapDataContext = (): IMapDataContext => {
  const ctx = useContext(MapDataContext);
  if (!ctx) throw new Error('useMapDataContext must be used inside MapDataContext.Provider');
  return ctx;
};

export const useMapHoverContext = (): IMapHoverContext => {
  const ctx = useContext(MapHoverContext);
  if (!ctx) throw new Error('useMapHoverContext must be used inside MapHoverContext.Provider');
  return ctx;
};
