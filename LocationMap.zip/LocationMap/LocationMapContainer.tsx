import { useCallback, useEffect, useMemo, useState } from 'react';
import { MapContainer, TileLayer, ZoomControl } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet.markercluster';
import { LocationMapController } from './LocationMapController';
import { LocationViewportListener } from './LocationViewportListener';
import { IMapDataContext, MapDataContext } from './MapContext';
import { MAP_DEFAULTS } from './mapConstants';
import { WorldMarkersLayer } from './layers/WorldMarkersLayer';
import { USAStatesMarkersLayer } from './layers/USAStatesMarkersLayer';
import { CountryMarkersLayer } from './layers/CountryMarkersLayer';
import { CityMarkersLayer } from './layers/CityMarkersLayer';

type Props = {
  mapBounds: L.LatLngBounds | null;
  mapCenter: [number, number] | null;
  mapZoom: number | null;
  context: IMapDataContext;
};

export const LocationMapContainer = ({ mapBounds, mapCenter, mapZoom, context }: Props) => {
  const [viewportBounds, setViewportBounds] = useState<L.LatLngBounds | null>(null);
  const [currentZoom, setCurrentZoom] = useState<number>(mapZoom ?? MAP_DEFAULTS.zoom);

  useEffect(() => {
    if (mapZoom !== null) setCurrentZoom(mapZoom);
  }, [mapZoom]);

  const handleViewportChange = useCallback((bounds: L.LatLngBounds) => setViewportBounds(bounds), []);
  const handleZoomChange = useCallback((zoom: number) => setCurrentZoom(zoom), []);

  // Re-provide the data context with the live Leaflet zoom. Memoized so a zoom
  // change doesn't churn a new object when nothing else changed.
  const mapContext = useMemo<IMapDataContext>(
    () => ({ ...context, currentZoom }),
    [context, currentZoom]
  );

  const { view, selectedCountry, selectedState, selectedCity } = context;

  return (
    <MapDataContext.Provider value={mapContext}>
      <MapContainer
        center={mapCenter ?? MAP_DEFAULTS.center}
        zoom={mapZoom ?? MAP_DEFAULTS.zoom}
        className='h-full w-full'
        zoomControl={false}
        preferCanvas
        attributionControl={false}
      >
        <TileLayer
          attribution='&copy; CARTO'
          url='https://{s}.basemaps.cartocdn.com/light_nolabels/{z}/{x}/{y}{r}.png'
        />
        <ZoomControl position='bottomright' />
        <LocationMapController bounds={mapBounds} center={mapCenter} zoom={mapZoom} />
        <LocationViewportListener
          onViewportChange={handleViewportChange}
          onZoomChange={handleZoomChange}
        />

        {view === 'world' && <WorldMarkersLayer />}
        {view === 'usa-states' && selectedCountry && <USAStatesMarkersLayer />}
        {view === 'country' && (selectedCountry || selectedState) && (
          <CountryMarkersLayer viewportBounds={viewportBounds} />
        )}
        {view === 'city' && selectedCity && <CityMarkersLayer viewportBounds={viewportBounds} />}
      </MapContainer>
    </MapDataContext.Provider>
  );
};
