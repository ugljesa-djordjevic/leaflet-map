import { useCallback, useEffect, useMemo, useState } from 'react';
import { MapContainer, TileLayer, ZoomControl } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet.markercluster';
import { LocationMapController } from './LocationMapController';
import { LocationViewportListener } from './LocationViewportListener';
import { IMapDataContext, MapDataContext } from './MapContext';
import { MAP_DEFAULTS } from './mapConstants';
import { ActiveMarkersLayer } from './layers/ActiveMarkersLayer';
import { useColorScheme } from '@mui/material';

type Props = {
  mapBounds: L.LatLngBounds | null;
  mapCenter: [number, number] | null;
  mapZoom: number | null;
  context: IMapDataContext;
};

export const LocationMapContainer = ({ mapBounds, mapCenter, mapZoom, context }: Props) => {
  const [viewportBounds, setViewportBounds] = useState<L.LatLngBounds | null>(null);
  const [currentZoom, setCurrentZoom] = useState<number>(mapZoom ?? MAP_DEFAULTS.zoom);
  const { mode } = useColorScheme();

  useEffect(() => {
    if (mapZoom !== null) setCurrentZoom(mapZoom);
  }, [mapZoom]);

  const handleViewportChange = useCallback(
    (bounds: L.LatLngBounds) => setViewportBounds(bounds),
    []
  );
  const handleZoomChange = useCallback((zoom: number) => setCurrentZoom(zoom), []);

  // Re-provide the data context with the live Leaflet zoom. Memoized so a zoom
  // change doesn't churn a new object when nothing else changed.
  const mapContext = useMemo<IMapDataContext>(
    () => ({ ...context, currentZoom }),
    [context, currentZoom]
  );

  return (
    <MapDataContext.Provider value={mapContext}>
      <MapContainer
        center={mapCenter ?? MAP_DEFAULTS.center}
        zoom={mapZoom ?? MAP_DEFAULTS.zoom}
        className='h-full w-full'
        zoomControl={false}
        preferCanvas
        attributionControl={false}
      >
        <TileLayer
          attribution='&copy; CARTO'
          url={`https://{s}.basemaps.cartocdn.com/${mode === 'dark' ? 'dark' : 'light'}_nolabels/{z}/{x}/{y}{r}.png`}
        />
        <ZoomControl position='bottomright' />
        <LocationMapController bounds={mapBounds} center={mapCenter} zoom={mapZoom} />
        <LocationViewportListener
          onViewportChange={handleViewportChange}
          onZoomChange={handleZoomChange}
        />

        <ActiveMarkersLayer viewportBounds={viewportBounds} />
      </MapContainer>
    </MapDataContext.Provider>
  );
};
