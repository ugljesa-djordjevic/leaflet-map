import { useMemo } from 'react';
import {
  useGetMapCitiesQuery,
  useGetMapStatesQuery,
  useGetMapSitesQuery,
} from 'src/services/locationMapService';
import { IMapCountry, StoresMarker } from 'src/models';

interface UseLocationMapDataParams {
  rawCountries: IMapCountry[];
  selectedCountry: GeoJSON.Feature | null;
  selectedState: GeoJSON.Feature | null;
  selectedCity: GeoJSON.Feature | null;
}

export const useLocationMapData = ({
  rawCountries,
  selectedCountry,
  selectedState,
  selectedCity,
}: UseLocationMapDataParams) => {
  const selectedCountryCode =
    selectedCountry?.properties?.ADM0_A3 ?? selectedCountry?.properties?.ISO_A3 ?? null;
  const selectedStateCode = selectedState?.properties?.stateCode ?? null;
  const selectedCityName = selectedCity?.properties?.NAME ?? null;

  const { data: mapStates = [] } = useGetMapStatesQuery(selectedCountryCode ?? '', {
    skip: !selectedCountryCode,
  });

  const { data: mapCities = [] } = useGetMapCitiesQuery(
    { countryCode: selectedCountryCode ?? undefined, stateCode: selectedStateCode ?? undefined },
    { skip: !selectedCountryCode && !selectedStateCode }
  );

  const { data: mapSites = [] } = useGetMapSitesQuery(
    {
      countryCode: selectedCountryCode ?? undefined,
      stateCode: selectedStateCode ?? undefined,
      cityName: selectedCityName ?? undefined,
    },
    { skip: !selectedCityName }
  );

  const countriesWithAvailability = useMemo(
    (): GeoJSON.Feature[] =>
      rawCountries.map((c) => ({
        type: 'Feature',
        geometry: { type: 'Point', coordinates: c.geoPosition.coordinates } as GeoJSON.Point,
        properties: {
          NAME: c.countryCode,
          ADM0_A3: c.countryCode,
          availability: Math.round(c.percentAvailable),
        },
      })),
    [rawCountries]
  );

  const usaStatesWithAvailability = useMemo(
    (): GeoJSON.Feature[] =>
      mapStates.map((s) => ({
        type: 'Feature',
        geometry: { type: 'Point', coordinates: s.geoPosition.coordinates } as GeoJSON.Point,
        properties: {
          name: s.stateName,
          postal: s.stateCode,
          stateCode: s.stateCode,
          countryCode: s.countryCode,
          availability: Math.round(s.percentAvailable),
        },
      })),
    [mapStates]
  );

  const citiesForCountry = useMemo((): GeoJSON.Feature[] => {
    if (!selectedCountry && !selectedState) return [];
    return mapCities.map((city) => ({
      type: 'Feature',
      geometry: { type: 'Point', coordinates: city.geoPosition.coordinates } as GeoJSON.Point,
      properties: {
        NAME: city.cityName,
        ADM0_A3: city.countryCode,
        stateCode: city.stateCode,
        availability: Math.round(city.percentAvailable),
      },
    }));
  }, [mapCities, selectedCountry, selectedState]);

  const storesForCity = useMemo(
    (): StoresMarker[] =>
      mapSites.map((site) => ({
        id: site.id,
        name: site.storeName,
        availability: Math.round(site.percentAvailable),
        lat: site.geoPosition.coordinates[1],
        lng: site.geoPosition.coordinates[0],
      })),
    [mapSites]
  );

  return { countriesWithAvailability, usaStatesWithAvailability, citiesForCountry, storesForCity };
};
