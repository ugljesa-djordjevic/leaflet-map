import { useEffect, useRef } from 'react';
import { IMapCountry, IMapState, IMapCity, IMapSite, StoresMarker } from 'src/models';

export interface IPendingNavigation {
  level: 'State' | 'City' | 'Store';
  countryCode: string;
  stateCode?: string;
  cityName?: string;
  storeValue?: string;
}

interface Params {
  pendingNavigation: IPendingNavigation | null;
  setPendingNavigation: (nav: IPendingNavigation | null) => void;
  rawCountries: IMapCountry[];
  rawStates: IMapState[];
  isFetchingStates: boolean;
  rawCities: IMapCity[];
  isFetchingCities: boolean;
  rawSites: IMapSite[];
  isFetchingSites: boolean;
  setIsNoData: (v: boolean) => void;
  resetToWorldInternal: () => void;
  applyStateNavigation: (state: GeoJSON.Feature, country: GeoJSON.Feature) => void;
  applyCityNavigation: (
    city: GeoJSON.Feature,
    country: GeoJSON.Feature,
    state: GeoJSON.Feature | null
  ) => void;
  applyStoreNavigation: (
    store: StoresMarker,
    country: GeoJSON.Feature,
    state: GeoJSON.Feature | null,
    city: GeoJSON.Feature | null
  ) => void;
}

export interface UsePendingNavigationResult {
  /** Resets dedup guards so a fresh navigation to the same target is re-processed. */
  clearResolvedRefs: () => void;
}

export const usePendingNavigation = ({
  pendingNavigation,
  setPendingNavigation,
  rawCountries,
  rawStates,
  isFetchingStates,
  rawCities,
  isFetchingCities,
  rawSites,
  isFetchingSites,
  setIsNoData,
  resetToWorldInternal,
  applyStateNavigation,
  applyCityNavigation,
  applyStoreNavigation,
}: Params): UsePendingNavigationResult => {
  const resolvedState = useRef<string | null>(null);
  const resolvedCity = useRef<string | null>(null);
  const resolvedStore = useRef<string | null>(null);

  // ---------------------------------------------------------------------------
  // Resolve pending State navigation once rawStates data arrives
  // ---------------------------------------------------------------------------
  useEffect(() => {
    if (!pendingNavigation || pendingNavigation.level !== 'State') return;
    if (resolvedState.current === pendingNavigation.stateCode) return;
    if (isFetchingStates) return;

    const rawState = rawStates.find((s) => s.stateCode === pendingNavigation.stateCode);
    if (!rawState) {
      if (import.meta.env.DEV)
        console.warn(
          `[LocationSwitcher→Map] State "${pendingNavigation.stateCode}" not found in map data. Resetting to world view.`
        );
      setIsNoData(true);
      setPendingNavigation(null);
      resetToWorldInternal();
      return;
    }
    const rawCountry = rawCountries.find((c) => c.countryCode === rawState.countryCode);
    if (!rawCountry) {
      if (import.meta.env.DEV)
        console.warn(
          `[LocationSwitcher→Map] Country "${rawState.countryCode}" for state not found. Resetting to world view.`
        );
      setIsNoData(true);
      setPendingNavigation(null);
      resetToWorldInternal();
      return;
    }
    resolvedState.current = pendingNavigation.stateCode ?? null;
    setIsNoData(false);
    const countryFeature: GeoJSON.Feature = {
      type: 'Feature',
      geometry: { type: 'Point', coordinates: rawCountry.geoPosition.coordinates },
      properties: {
        NAME: rawCountry.countryCode,
        ADM0_A3: rawCountry.countryCode,
        ISO_A3: rawCountry.countryCode,
      },
    };
    const stateFeature: GeoJSON.Feature = {
      type: 'Feature',
      geometry: { type: 'Point', coordinates: rawState.geoPosition.coordinates },
      properties: {
        name: rawState.stateName,
        postal: rawState.stateCode,
        stateCode: rawState.stateCode,
        countryCode: rawState.countryCode,
      },
    };
    applyStateNavigation(stateFeature, countryFeature);
    setPendingNavigation(null);
  }, [
    rawStates,
    isFetchingStates,
    pendingNavigation,
    rawCountries,
    applyStateNavigation,
    resetToWorldInternal,
    setIsNoData,
    setPendingNavigation,
  ]);

  // ---------------------------------------------------------------------------
  // Resolve pending City navigation once rawCities data arrives
  // ---------------------------------------------------------------------------
  useEffect(() => {
    if (!pendingNavigation || pendingNavigation.level !== 'City') return;
    if (resolvedCity.current === pendingNavigation.cityName) return;
    if (isFetchingCities) return;

    const rawCity = rawCities.find((c) => c.cityName === pendingNavigation.cityName);
    if (!rawCity) {
      if (import.meta.env.DEV)
        console.warn(
          `[LocationSwitcher→Map] City "${pendingNavigation.cityName}" not found. Resetting to world view.`
        );
      setIsNoData(true);
      setPendingNavigation(null);
      resetToWorldInternal();
      return;
    }
    const rawCountry = rawCountries.find((c) => c.countryCode === rawCity.countryCode);
    if (!rawCountry) {
      if (import.meta.env.DEV)
        console.warn(
          `[LocationSwitcher→Map] Country "${rawCity.countryCode}" for city not found. Resetting to world view.`
        );
      setIsNoData(true);
      setPendingNavigation(null);
      resetToWorldInternal();
      return;
    }
    resolvedCity.current = pendingNavigation.cityName ?? null;
    setIsNoData(false);
    const countryFeature: GeoJSON.Feature = {
      type: 'Feature',
      geometry: { type: 'Point', coordinates: rawCountry.geoPosition.coordinates },
      properties: {
        NAME: rawCountry.countryCode,
        ADM0_A3: rawCountry.countryCode,
        ISO_A3: rawCountry.countryCode,
      },
    };
    const stateFeature: GeoJSON.Feature | null = rawCity.stateCode
      ? {
          type: 'Feature',
          geometry: { type: 'Point', coordinates: [0, 0] },
          properties: {
            name: rawCity.stateName,
            postal: rawCity.stateCode,
            stateCode: rawCity.stateCode,
            countryCode: rawCity.countryCode,
          },
        }
      : null;
    const cityFeature: GeoJSON.Feature = {
      type: 'Feature',
      geometry: { type: 'Point', coordinates: rawCity.geoPosition.coordinates },
      properties: {
        NAME: rawCity.cityName,
        ADM0_A3: rawCity.countryCode,
        stateCode: rawCity.stateCode,
      },
    };
    applyCityNavigation(cityFeature, countryFeature, stateFeature);
    setPendingNavigation(null);
  }, [
    rawCities,
    isFetchingCities,
    pendingNavigation,
    rawCountries,
    applyCityNavigation,
    resetToWorldInternal,
    setIsNoData,
    setPendingNavigation,
  ]);

  // ---------------------------------------------------------------------------
  // Resolve pending Store navigation once rawSites data arrives
  // ---------------------------------------------------------------------------
  useEffect(() => {
    if (!pendingNavigation || pendingNavigation.level !== 'Store') return;
    if (resolvedStore.current === pendingNavigation.storeValue) return;
    if (isFetchingSites) return;

    const rawSite = rawSites.find(
      (s) =>
        s.siteId === pendingNavigation.storeValue || s.storeNbr === pendingNavigation.storeValue
    );
    if (!rawSite) {
      if (import.meta.env.DEV)
        console.warn(
          `[LocationSwitcher→Map] Store "${pendingNavigation.storeValue}" not found. Resetting to world view.`
        );
      setIsNoData(true);
      setPendingNavigation(null);
      resetToWorldInternal();
      return;
    }
    const rawCountry = rawCountries.find((c) => c.countryCode === rawSite.countryCode);
    if (!rawCountry) {
      if (import.meta.env.DEV)
        console.warn(
          `[LocationSwitcher→Map] Country "${rawSite.countryCode}" for store not found. Resetting to world view.`
        );
      setIsNoData(true);
      setPendingNavigation(null);
      resetToWorldInternal();
      return;
    }
    resolvedStore.current = pendingNavigation.storeValue ?? null;
    setIsNoData(false);
    const countryFeature: GeoJSON.Feature = {
      type: 'Feature',
      geometry: { type: 'Point', coordinates: rawCountry.geoPosition.coordinates },
      properties: {
        NAME: rawCountry.countryCode,
        ADM0_A3: rawCountry.countryCode,
        ISO_A3: rawCountry.countryCode,
      },
    };
    const stateFeature: GeoJSON.Feature | null = rawSite.stateCode
      ? {
          type: 'Feature',
          geometry: { type: 'Point', coordinates: [0, 0] },
          properties: {
            name: rawSite.stateName,
            postal: rawSite.stateCode,
            stateCode: rawSite.stateCode,
            countryCode: rawSite.countryCode,
          },
        }
      : null;
    const cityFeature: GeoJSON.Feature | null = rawSite.cityName
      ? {
          type: 'Feature',
          geometry: { type: 'Point', coordinates: rawSite.geoPosition.coordinates },
          properties: {
            NAME: rawSite.cityName,
            ADM0_A3: rawSite.countryCode,
            stateCode: rawSite.stateCode,
          },
        }
      : null;
    const storeMarker: StoresMarker = {
      id: rawSite.id,
      name: rawSite.storeName,
      availability: Math.round(rawSite.percentAvailable),
      lat: rawSite.geoPosition.coordinates[1],
      lng: rawSite.geoPosition.coordinates[0],
    };
    applyStoreNavigation(storeMarker, countryFeature, stateFeature, cityFeature);
    setPendingNavigation(null);
  }, [
    rawSites,
    isFetchingSites,
    pendingNavigation,
    rawCountries,
    applyStoreNavigation,
    resetToWorldInternal,
    setIsNoData,
    setPendingNavigation,
  ]);

  return {
    clearResolvedRefs: () => {
      resolvedState.current = null;
      resolvedCity.current = null;
      resolvedStore.current = null;
    },
  };
};
