import { useState, useMemo, useCallback, useEffect, useRef } from 'react';
import L from 'leaflet';
import { useAppDispatch, useAppSelector } from 'src/store/hooks';
import {
  locationFilterChanged,
  selectCurrentLocationFilter,
} from 'src/store/slices/dashboardFiltersSlice';
import { ICustomerLocation } from 'src/models/Customer';
import { StoresMarker } from 'src/models';
import { MapView } from '../mapUtils';
import {
  useGetMapCountriesQuery,
  useGetMapStatesQuery,
  useGetMapCitiesQuery,
  useGetMapSitesQuery,
} from 'src/services/locationMapService';

// Encapsulates state needed to complete a navigation that requires lazy-loaded data.
interface IPendingNavigation {
  level: 'State' | 'City' | 'Store';
  countryCode: string;
  stateCode?: string;
  cityName?: string;
  storeValue?: string;
}

export const useMapNavigation = () => {
  const [view, setView] = useState<MapView>('world');
  const [selectedCountry, setSelectedCountry] = useState<GeoJSON.Feature | null>(null);
  const [selectedState, setSelectedState] = useState<GeoJSON.Feature | null>(null);
  const [selectedCity, setSelectedCity] = useState<GeoJSON.Feature | null>(null);
  const [selectedStore, setSelectedStore] = useState<StoresMarker | null>(null);
  const [mapBounds, setMapBounds] = useState<L.LatLngBounds | null>(null);
  const [mapCenter, setMapCenter] = useState<[number, number] | null>([30, 0]);
  const [mapZoom, setMapZoom] = useState<number | null>(3);
  const [page, setPage] = useState<number>(0);
  const [hoveredId, setHoveredId] = useState<string | null>(null);

  // Tracks a multi-step navigation triggered from the LocationSwitcher filter.
  const [pendingNavigation, setPendingNavigation] = useState<IPendingNavigation | null>(null);

  const dispatch = useAppDispatch();
  const filterLocation = useAppSelector(selectCurrentLocationFilter);

  // --- Data for external filter sync (RTK Query caches these, no duplicate fetches) ---
  const { data: rawCountries = [] } = useGetMapCountriesQuery();

  const { data: rawStates = [], isFetching: isFetchingStates } = useGetMapStatesQuery(
    pendingNavigation?.countryCode ?? '',
    { skip: !pendingNavigation?.countryCode }
  );

  const { data: rawCities = [], isFetching: isFetchingCities } = useGetMapCitiesQuery(
    {
      countryCode: pendingNavigation?.countryCode,
      stateCode: pendingNavigation?.stateCode,
    },
    {
      skip:
        !pendingNavigation ||
        (pendingNavigation.level !== 'City' && pendingNavigation.level !== 'Store'),
    }
  );

  const { data: rawSites = [], isFetching: isFetchingSites } = useGetMapSitesQuery(
    {
      countryCode: pendingNavigation?.countryCode,
      stateCode: pendingNavigation?.stateCode,
      cityName: pendingNavigation?.cityName,
    },
    { skip: !pendingNavigation || pendingNavigation.level !== 'Store' }
  );

  const selectLocation = useCallback(
    (location: ICustomerLocation | null) => dispatch(locationFilterChanged(location)),
    [dispatch]
  );

  // ---------------------------------------------------------------------------
  // Internal navigators — update local map state WITHOUT re-dispatching to Redux.
  // Used when a change originates from the LocationSwitcher so we don't loop.
  // ---------------------------------------------------------------------------
  // Shared helper: reset map to world view without touching Redux.
  // Used for graceful degradation when the map has no data for the selected location.
  // ---------------------------------------------------------------------------
  const resetToWorldInternal = useCallback(() => {
    setSelectedCity(null);
    setSelectedState(null);
    setSelectedCountry(null);
    setSelectedStore(null);
    setPendingNavigation(null);
    setView('world');
    setMapBounds(null);
    setMapCenter([30, 0]);
    setMapZoom(3);
    setPage(0);
  }, []);

  const applyCountryNavigation = useCallback(
    (countryCode: string) => {
      // Match priority:
      // 1. Exact code match (GBR === GBR)
      // 2. Case-insensitive (gbr === GBR)
      // 3. ISO-2/ISO-3 prefix: one is a prefix of the other (GB vs GBR, US vs USA)
      const normalised = countryCode.toUpperCase();
      const raw =
        rawCountries.find((c) => c.countryCode === countryCode) ??
        rawCountries.find((c) => c.countryCode.toUpperCase() === normalised) ??
        rawCountries.find(
          (c) =>
            c.countryCode.toUpperCase().startsWith(normalised) ||
            normalised.startsWith(c.countryCode.toUpperCase())
        );
      if (!raw) {
        if (import.meta.env.DEV)
          console.warn(
            `[LocationSwitcher→Map] Country not found in map data: "${countryCode}". rawCountries has ${rawCountries.length} entries. Resetting to world view.`
          );
        resetToWorldInternal();
        return;
      }
      const isUSA = raw.countryCode === 'USA' || raw.countryCode === 'US';
      const feature: GeoJSON.Feature = {
        type: 'Feature',
        geometry: { type: 'Point', coordinates: raw.geoPosition.coordinates },
        properties: { NAME: raw.countryCode, ADM0_A3: raw.countryCode, ISO_A3: raw.countryCode },
      };
      setSelectedCountry(feature);
      setSelectedState(null);
      setSelectedCity(null);
      setSelectedStore(null);
      setView(isUSA ? 'usa-states' : 'country');
      setMapBounds(null);
      setMapCenter([raw.geoPosition.coordinates[1], raw.geoPosition.coordinates[0]]);
      setMapZoom(5);
      setPage(0);
    },
    [rawCountries, resetToWorldInternal]
  );

  const applyStateNavigation = useCallback(
    (stateFeature: GeoJSON.Feature, countryFeature: GeoJSON.Feature) => {
      setSelectedCountry(countryFeature);
      setSelectedState(stateFeature);
      setSelectedCity(null);
      setSelectedStore(null);
      setView('country');
      setMapBounds(null);
      const coords = (stateFeature.geometry as GeoJSON.Point).coordinates;
      setMapCenter([coords[1], coords[0]]);
      setMapZoom(7);
      setPage(0);
    },
    []
  );

  const applyCityNavigation = useCallback(
    (
      cityFeature: GeoJSON.Feature,
      countryFeature: GeoJSON.Feature,
      stateFeature: GeoJSON.Feature | null
    ) => {
      setSelectedCountry(countryFeature);
      setSelectedState(stateFeature);
      setSelectedCity(cityFeature);
      setSelectedStore(null);
      setView('city');
      setMapBounds(null);
      const coords = (cityFeature.geometry as GeoJSON.Point).coordinates;
      setMapCenter([coords[1], coords[0]]);
      setMapZoom(13);
      setPage(0);
    },
    []
  );

  const applyStoreNavigation = useCallback(
    (
      store: StoresMarker,
      countryFeature: GeoJSON.Feature,
      stateFeature: GeoJSON.Feature | null,
      cityFeature: GeoJSON.Feature | null
    ) => {
      setSelectedCountry(countryFeature);
      setSelectedState(stateFeature);
      setSelectedCity(cityFeature);
      setSelectedStore(store);
      setMapBounds(null);
      setMapCenter([store.lat, store.lng]);
      setMapZoom(15);
      setPage(0);
    },
    []
  );

  // ---------------------------------------------------------------------------
  // Resolve pending State navigation once rawStates data is available
  // ---------------------------------------------------------------------------
  const resolvedPendingState = useRef<string | null>(null);
  useEffect(() => {
    if (!pendingNavigation || pendingNavigation.level !== 'State') return;
    if (resolvedPendingState.current === pendingNavigation.stateCode) return;
    if (isFetchingStates) return; // still loading

    const rawState = rawStates.find((s) => s.stateCode === pendingNavigation.stateCode);
    if (!rawState) {
      if (import.meta.env.DEV)
        console.warn(
          `[LocationSwitcher→Map] State "${pendingNavigation.stateCode}" not found in map data. Resetting to world view.`
        );
      setPendingNavigation(null);
      resetToWorldInternal();
      return;
    }

    const rawCountry = rawCountries.find((c) => c.countryCode === rawState.countryCode);
    if (!rawCountry) {
      if (import.meta.env.DEV)
        console.warn(
          `[LocationSwitcher→Map] Country "${rawState.countryCode}" for state not found in map data. Resetting to world view.`
        );
      setPendingNavigation(null);
      resetToWorldInternal();
      return;
    }

    resolvedPendingState.current = pendingNavigation.stateCode ?? null;

    const countryFeature: GeoJSON.Feature = {
      type: 'Feature',
      geometry: { type: 'Point', coordinates: rawCountry.geoPosition.coordinates },
      properties: {
        NAME: rawCountry.countryCode,
        ADM0_A3: rawCountry.countryCode,
        ISO_A3: rawCountry.countryCode,
      },
    };
    const stateFeature: GeoJSON.Feature = {
      type: 'Feature',
      geometry: { type: 'Point', coordinates: rawState.geoPosition.coordinates },
      properties: {
        name: rawState.stateName,
        postal: rawState.stateCode,
        stateCode: rawState.stateCode,
        countryCode: rawState.countryCode,
      },
    };
    applyStateNavigation(stateFeature, countryFeature);
    setPendingNavigation(null);
  }, [
    rawStates,
    isFetchingStates,
    pendingNavigation,
    rawCountries,
    applyStateNavigation,
    resetToWorldInternal,
  ]);

  // ---------------------------------------------------------------------------
  // Resolve pending City navigation once rawCities data is available
  // ---------------------------------------------------------------------------
  const resolvedPendingCity = useRef<string | null>(null);
  useEffect(() => {
    if (!pendingNavigation || pendingNavigation.level !== 'City') return;
    if (resolvedPendingCity.current === pendingNavigation.cityName) return;
    if (isFetchingCities) return; // still loading

    const rawCity = rawCities.find((c) => c.cityName === pendingNavigation.cityName);
    if (!rawCity) {
      if (import.meta.env.DEV)
        console.warn(
          `[LocationSwitcher→Map] City "${pendingNavigation.cityName}" not found in map data. Resetting to world view.`
        );
      setPendingNavigation(null);
      resetToWorldInternal();
      return;
    }

    const rawCountry = rawCountries.find((c) => c.countryCode === rawCity.countryCode);
    if (!rawCountry) {
      if (import.meta.env.DEV)
        console.warn(
          `[LocationSwitcher→Map] Country "${rawCity.countryCode}" for city not found in map data. Resetting to world view.`
        );
      setPendingNavigation(null);
      resetToWorldInternal();
      return;
    }

    resolvedPendingCity.current = pendingNavigation.cityName ?? null;

    const countryFeature: GeoJSON.Feature = {
      type: 'Feature',
      geometry: { type: 'Point', coordinates: rawCountry.geoPosition.coordinates },
      properties: {
        NAME: rawCountry.countryCode,
        ADM0_A3: rawCountry.countryCode,
        ISO_A3: rawCountry.countryCode,
      },
    };
    const stateFeature: GeoJSON.Feature | null = rawCity.stateCode
      ? {
          type: 'Feature',
          geometry: { type: 'Point', coordinates: [0, 0] }, // coordinates not needed for city view
          properties: {
            name: rawCity.stateName,
            postal: rawCity.stateCode,
            stateCode: rawCity.stateCode,
            countryCode: rawCity.countryCode,
          },
        }
      : null;
    const cityFeature: GeoJSON.Feature = {
      type: 'Feature',
      geometry: { type: 'Point', coordinates: rawCity.geoPosition.coordinates },
      properties: {
        NAME: rawCity.cityName,
        ADM0_A3: rawCity.countryCode,
        stateCode: rawCity.stateCode,
      },
    };
    applyCityNavigation(cityFeature, countryFeature, stateFeature);
    setPendingNavigation(null);
  }, [
    rawCities,
    isFetchingCities,
    pendingNavigation,
    rawCountries,
    applyCityNavigation,
    resetToWorldInternal,
  ]);

  // ---------------------------------------------------------------------------
  // Resolve pending Store navigation once rawSites data is available
  // ---------------------------------------------------------------------------
  const resolvedPendingStore = useRef<string | null>(null);
  useEffect(() => {
    if (!pendingNavigation || pendingNavigation.level !== 'Store') return;
    if (resolvedPendingStore.current === pendingNavigation.storeValue) return;
    if (isFetchingSites) return; // still loading

    // Match by siteId or storeNbr (the filter value may be either)
    const rawSite = rawSites.find(
      (s) =>
        s.siteId === pendingNavigation.storeValue || s.storeNbr === pendingNavigation.storeValue
    );
    if (!rawSite) {
      if (import.meta.env.DEV)
        console.warn(
          `[LocationSwitcher→Map] Store "${pendingNavigation.storeValue}" not found in map data. Resetting to world view.`
        );
      setPendingNavigation(null);
      resetToWorldInternal();
      return;
    }

    const rawCountry = rawCountries.find((c) => c.countryCode === rawSite.countryCode);
    if (!rawCountry) {
      if (import.meta.env.DEV)
        console.warn(
          `[LocationSwitcher→Map] Country "${rawSite.countryCode}" for store not found in map data. Resetting to world view.`
        );
      setPendingNavigation(null);
      resetToWorldInternal();
      return;
    }

    resolvedPendingStore.current = pendingNavigation.storeValue ?? null;

    const countryFeature: GeoJSON.Feature = {
      type: 'Feature',
      geometry: { type: 'Point', coordinates: rawCountry.geoPosition.coordinates },
      properties: {
        NAME: rawCountry.countryCode,
        ADM0_A3: rawCountry.countryCode,
        ISO_A3: rawCountry.countryCode,
      },
    };
    const stateFeature: GeoJSON.Feature | null = rawSite.stateCode
      ? {
          type: 'Feature',
          geometry: { type: 'Point', coordinates: [0, 0] },
          properties: {
            name: rawSite.stateName,
            postal: rawSite.stateCode,
            stateCode: rawSite.stateCode,
            countryCode: rawSite.countryCode,
          },
        }
      : null;
    const cityFeature: GeoJSON.Feature | null = rawSite.cityName
      ? {
          type: 'Feature',
          geometry: { type: 'Point', coordinates: rawSite.geoPosition.coordinates },
          properties: {
            NAME: rawSite.cityName,
            ADM0_A3: rawSite.countryCode,
            stateCode: rawSite.stateCode,
          },
        }
      : null;
    const storeMarker: StoresMarker = {
      id: rawSite.siteId,
      name: rawSite.storeName,
      availability: Math.round(rawSite.percentAvailable),
      lat: rawSite.geoPosition.coordinates[1],
      lng: rawSite.geoPosition.coordinates[0],
    };
    applyStoreNavigation(storeMarker, countryFeature, stateFeature, cityFeature);
    setPendingNavigation(null);
  }, [
    rawSites,
    isFetchingSites,
    pendingNavigation,
    rawCountries,
    applyStoreNavigation,
    resetToWorldInternal,
  ]);

  // ---------------------------------------------------------------------------
  // React to external filter changes (from LocationSwitcher)
  // Guard: if the current map state already matches the filter value, skip.
  // ---------------------------------------------------------------------------
  const prevFilterRef = useRef<typeof filterLocation>(filterLocation);
  useEffect(() => {
    const prev = prevFilterRef.current;
    prevFilterRef.current = filterLocation;

    // No change — nothing to do
    if (filterLocation === prev) return;

    // Reset to world
    if (!filterLocation) {
      if (view === 'world' && !selectedCountry) return;
      resolvedPendingState.current = null;
      resolvedPendingCity.current = null;
      resolvedPendingStore.current = null;
      resetToWorldInternal();
      return;
    }

    const { level, value, countryCode, stateCode, cityName } = filterLocation;

    // Region is above Country — the map has no region concept; reset to world.
    if (level === 'Region') {
      if (view === 'world' && !selectedCountry) return;
      resolvedPendingState.current = null;
      resolvedPendingCity.current = null;
      resolvedPendingStore.current = null;
      resetToWorldInternal();
      return;
    }

    if (level === 'Country') {
      // Already on this country — map dispatched this; ignore
      const alreadySelected =
        selectedCountry?.properties?.ADM0_A3 === value ||
        selectedCountry?.properties?.ISO_A3 === value;
      if (alreadySelected) return;
      applyCountryNavigation(value);
      return;
    }

    if (level === 'State') {
      if (selectedState?.properties?.postal === value) return;
      if (!countryCode) {
        if (import.meta.env.DEV)
          console.warn(
            `[LocationSwitcher→Map] Cannot navigate to State "${value}" — countryCode is missing. Rebuild & restart the backend. Resetting to world view.`
          );
        resetToWorldInternal();
        return;
      }
      resolvedPendingState.current = null;
      setPendingNavigation({ level: 'State', countryCode, stateCode: value });
      return;
    }

    if (level === 'City') {
      if (selectedCity?.properties?.NAME === value) return;
      if (!countryCode) {
        if (import.meta.env.DEV)
          console.warn(
            `[LocationSwitcher→Map] Cannot navigate to City "${value}" — countryCode is missing. Rebuild & restart the backend. Resetting to world view.`
          );
        resetToWorldInternal();
        return;
      }
      resolvedPendingCity.current = null;
      setPendingNavigation({ level: 'City', countryCode, stateCode, cityName: value });
      return;
    }

    if (level === 'Store' || level === 'Store Nbr') {
      if (selectedStore?.id === value) return;
      if (!countryCode) {
        if (import.meta.env.DEV)
          console.warn(
            `[LocationSwitcher→Map] Cannot navigate to Store "${value}" — countryCode is missing. Rebuild & restart the backend. Resetting to world view.`
          );
        resetToWorldInternal();
        return;
      }
      resolvedPendingStore.current = null;
      setPendingNavigation({ level: 'Store', countryCode, stateCode, cityName, storeValue: value });
      return;
    }

    if (import.meta.env.DEV)
      console.warn(
        `[LocationSwitcher→Map] Unhandled location level: "${level}" (value: "${value}"). Navigation not implemented for this level.`
      );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filterLocation]);

  const navigateToWorld = useCallback(() => {
    setSelectedCity(null);
    setSelectedState(null);
    setSelectedCountry(null);
    setSelectedStore(null);
    setView('world');
    setMapBounds(null);
    setMapCenter([30, 0]);
    setMapZoom(3);
    setPage(0);
    selectLocation(null);
  }, [selectLocation]);

  const navigateToCountryOrStates = useCallback(() => {
    if (!selectedCountry) return;
    const isUSA =
      selectedCountry.properties?.ADM0_A3 === 'USA' || selectedCountry.properties?.ISO_A3 === 'USA';
    setSelectedCity(null);
    setSelectedState(null);
    setSelectedStore(null);
    setView(isUSA ? 'usa-states' : 'country');
    setMapBounds(null);
    const coords = (selectedCountry.geometry as GeoJSON.Point).coordinates;
    setMapCenter([coords[1], coords[0]]);
    setMapZoom(5);
    setPage(0);
    const displayName =
      selectedCountry.properties?.NAME || selectedCountry.properties?.ADM0_A3 || 'Country';
    const value = selectedCountry.properties?.ADM0_A3 || displayName;
    selectLocation({ displayName, value, level: isUSA ? 'State' : 'Country' });
  }, [selectedCountry, selectLocation]);

  const navigateToState = useCallback(() => {
    if (!selectedState) return;
    setSelectedCity(null);
    setSelectedStore(null);
    setView('country');
    setMapBounds(null);
    const coords = (selectedState.geometry as GeoJSON.Point).coordinates;
    setMapCenter([coords[1], coords[0]]);
    setMapZoom(7);
    setPage(0);
    const displayName =
      selectedState.properties?.name || selectedState.properties?.postal || 'State';
    const value = selectedState.properties?.postal || selectedState.properties?.name || displayName;
    selectLocation({ displayName, value, level: 'State' });
  }, [selectedState, selectLocation]);

  const handleCountrySelect = useCallback(
    (country: GeoJSON.Feature) => {
      const isUSA = country.properties?.ADM0_A3 === 'USA' || country.properties?.ISO_A3 === 'USA';
      setSelectedCountry(country);
      setSelectedState(null);
      setSelectedCity(null);
      setSelectedStore(null);
      setView(isUSA ? 'usa-states' : 'country');
      setMapBounds(null);
      const coords = (country.geometry as GeoJSON.Point).coordinates;
      setMapCenter([coords[1], coords[0]]);
      setMapZoom(5);
      setPage(0);
      const displayName = country.properties?.NAME || country.properties?.ADM0_A3 || 'Country';
      const value = country.properties?.ADM0_A3 || displayName;
      selectLocation({ displayName, value, level: 'Country' });
    },
    [selectLocation]
  );

  const handleStateSelect = useCallback(
    (state: GeoJSON.Feature) => {
      setSelectedState(state);
      setSelectedCity(null);
      setSelectedStore(null);
      setView('country');
      setMapBounds(null);
      const coords = (state.geometry as GeoJSON.Point).coordinates;
      setMapCenter([coords[1], coords[0]]);
      setMapZoom(7);
      setPage(0);
      const displayName = state.properties?.name || state.properties?.postal || 'State';
      const value = state.properties?.postal || state.properties?.name || displayName;
      selectLocation({ displayName, value, level: 'State' });
    },
    [selectLocation]
  );

  const handleCitySelect = useCallback(
    (city: GeoJSON.Feature) => {
      setSelectedCity(city);
      setSelectedStore(null);
      setView('city');
      setMapBounds(null);
      const coords = (city.geometry as GeoJSON.Point).coordinates;
      setMapCenter([coords[1], coords[0]]);
      setMapZoom(13);
      setPage(0);
      const displayName = city.properties?.NAME || 'City';
      selectLocation({ displayName, value: displayName, level: 'City' });
    },
    [selectLocation]
  );

  const handleStoreSelect = useCallback(
    (store: StoresMarker) => {
      setSelectedStore(store);
      setMapBounds(null);
      setMapCenter([store.lat, store.lng]);
      setMapZoom(15);
      setPage(0);
      selectLocation({ displayName: store.name, value: store.id, level: 'Store' });
    },
    [selectLocation]
  );

  const handleStoreBreadcrumbClick = useCallback(() => {
    if (selectedStore && selectedCity) handleStoreSelect(selectedStore);
  }, [handleStoreSelect, selectedCity, selectedStore]);

  const breadcrumbs = useMemo(() => {
    const crumbs: { label: string; onClick?: () => void }[] = [];
    const countryIsUSA =
      selectedCountry?.properties?.ADM0_A3 === 'USA' ||
      selectedCountry?.properties?.ISO_A3 === 'USA';

    crumbs.push({ label: 'World', onClick: navigateToWorld });

    if (selectedCountry) {
      const countryLabel = countryIsUSA
        ? 'United States'
        : selectedCountry.properties?.NAME || selectedCountry.properties?.ADM0_A3 || 'Country';
      crumbs.push({ label: countryLabel, onClick: navigateToCountryOrStates });
    }

    if (selectedState) {
      const stateLabel =
        selectedState.properties?.name || selectedState.properties?.postal || 'State';
      crumbs.push({ label: stateLabel, onClick: navigateToState });
    }

    if (selectedCity) {
      crumbs.push({ label: selectedCity.properties?.NAME || 'City' });
    }

    if (selectedStore) {
      crumbs.push({ label: selectedStore.name, onClick: handleStoreBreadcrumbClick });
    }

    return crumbs;
  }, [
    navigateToWorld,
    navigateToCountryOrStates,
    navigateToState,
    selectedCountry,
    selectedState,
    selectedCity,
    selectedStore,
    handleStoreBreadcrumbClick,
  ]);

  return {
    view,
    selectedCountry,
    selectedState,
    selectedCity,
    selectedStore,
    mapBounds,
    mapCenter,
    mapZoom,
    page,
    setPage,
    hoveredId,
    setHoveredId,
    breadcrumbs,
    handleCountrySelect,
    handleStateSelect,
    handleCitySelect,
    handleStoreSelect,
  };
};
