import { useState, useCallback } from 'react';
import L from 'leaflet';
import { useAppDispatch } from 'src/store/hooks';
import { locationFilterChanged } from 'src/store/slices/dashboardFiltersSlice';
import { ICustomerLocation } from 'src/models/Customer';
import { IMapCountry, StoresMarker } from 'src/models';
import {
  useGetMapStatesQuery,
  useGetMapCitiesQuery,
  useGetMapSitesQuery,
} from 'src/services/locationMapService';
import { MapView } from '../mapUtils';
import { usePendingNavigation, IPendingNavigation } from './usePendingNavigation';
import { useFilterSync } from './useFilterSync';
import { useBreadcrumbs } from './useBreadcrumbs';

interface UseMapNavigationParams {
  rawCountries: IMapCountry[];
}

export const useMapNavigation = ({ rawCountries }: UseMapNavigationParams) => {
  const [view, setView] = useState<MapView>('world');
  const [selectedCountry, setSelectedCountry] = useState<GeoJSON.Feature | null>(null);
  const [selectedState, setSelectedState] = useState<GeoJSON.Feature | null>(null);
  const [selectedCity, setSelectedCity] = useState<GeoJSON.Feature | null>(null);
  const [selectedStore, setSelectedStore] = useState<StoresMarker | null>(null);
  const [mapBounds, setMapBounds] = useState<L.LatLngBounds | null>(null);
  const [mapCenter, setMapCenter] = useState<[number, number] | null>([30, 0]);
  const [mapZoom, setMapZoom] = useState<number | null>(3);
  const [page, setPage] = useState<number>(0);
  const [isNoData, setIsNoData] = useState<boolean>(false);

  // Tracks a multi-step navigation triggered from the LocationSwitcher filter.
  const [pendingNavigation, setPendingNavigation] = useState<IPendingNavigation | null>(null);

  const dispatch = useAppDispatch();

  // --- RTK Query for pending navigation resolution (args differ from display queries) ---
  const { data: rawStates = [], isFetching: isFetchingStates } = useGetMapStatesQuery(
    pendingNavigation?.countryCode ?? '',
    { skip: !pendingNavigation?.countryCode }
  );

  const { data: rawCities = [], isFetching: isFetchingCities } = useGetMapCitiesQuery(
    {
      countryCode: pendingNavigation?.countryCode,
      stateCode: pendingNavigation?.stateCode,
    },
    {
      skip:
        !pendingNavigation ||
        (pendingNavigation.level !== 'City' && pendingNavigation.level !== 'Store'),
    }
  );

  const { data: rawSites = [], isFetching: isFetchingSites } = useGetMapSitesQuery(
    {
      countryCode: pendingNavigation?.countryCode,
      stateCode: pendingNavigation?.stateCode,
      cityName: pendingNavigation?.cityName,
    },
    { skip: !pendingNavigation || pendingNavigation.level !== 'Store' }
  );

  const selectLocation = useCallback(
    (location: ICustomerLocation | null) => dispatch(locationFilterChanged(location)),
    [dispatch]
  );

  // ---------------------------------------------------------------------------
  // Internal navigators — update local map state WITHOUT re-dispatching to Redux.
  // Used when a change originates from the LocationSwitcher so we don't loop.
  // ---------------------------------------------------------------------------
  // Shared helper: reset map to world view without touching Redux.
  // Used for graceful degradation when the map has no data for the selected location.
  // ---------------------------------------------------------------------------
  const resetToWorldInternal = useCallback(() => {
    setSelectedCity(null);
    setSelectedState(null);
    setSelectedCountry(null);
    setSelectedStore(null);
    setPendingNavigation(null);
    setView('world');
    setMapBounds(null);
    setMapCenter([30, 0]);
    setMapZoom(3);
    setPage(0);
  }, []);

  const applyCountryNavigation = useCallback(
    (countryCode: string) => {
      // Match priority:
      // 1. Exact code match (GBR === GBR)
      // 2. Case-insensitive (gbr === GBR)
      // 3. ISO-2/ISO-3 prefix: one is a prefix of the other (GB vs GBR, US vs USA)
      const normalised = countryCode.toUpperCase();
      const raw =
        rawCountries.find((c) => c.countryCode === countryCode) ??
        rawCountries.find((c) => c.countryCode.toUpperCase() === normalised) ??
        rawCountries.find(
          (c) =>
            c.countryCode.toUpperCase().startsWith(normalised) ||
            normalised.startsWith(c.countryCode.toUpperCase())
        );
      if (!raw) {
        if (import.meta.env.DEV)
          console.warn(
            `[LocationSwitcher→Map] Country not found in map data: "${countryCode}". rawCountries has ${rawCountries.length} entries. Resetting to world view.`
          );
        setIsNoData(true);
        resetToWorldInternal();
        return;
      }
      setIsNoData(false);
      const isUSA = raw.countryCode === 'USA' || raw.countryCode === 'US';
      const feature: GeoJSON.Feature = {
        type: 'Feature',
        geometry: { type: 'Point', coordinates: raw.geoPosition.coordinates },
        properties: { NAME: raw.countryCode, ADM0_A3: raw.countryCode, ISO_A3: raw.countryCode },
      };
      setSelectedCountry(feature);
      setSelectedState(null);
      setSelectedCity(null);
      setSelectedStore(null);
      setView(isUSA ? 'usa-states' : 'country');
      setMapBounds(null);
      setMapCenter([raw.geoPosition.coordinates[1], raw.geoPosition.coordinates[0]]);
      setMapZoom(5);
      setPage(0);
    },
    [rawCountries, resetToWorldInternal]
  );

  const applyStateNavigation = useCallback(
    (stateFeature: GeoJSON.Feature, countryFeature: GeoJSON.Feature) => {
      setSelectedCountry(countryFeature);
      setSelectedState(stateFeature);
      setSelectedCity(null);
      setSelectedStore(null);
      setView('country');
      setMapBounds(null);
      const coords = (stateFeature.geometry as GeoJSON.Point).coordinates;
      setMapCenter([coords[1], coords[0]]);
      setMapZoom(7);
      setPage(0);
    },
    []
  );

  const applyCityNavigation = useCallback(
    (
      cityFeature: GeoJSON.Feature,
      countryFeature: GeoJSON.Feature,
      stateFeature: GeoJSON.Feature | null
    ) => {
      setSelectedCountry(countryFeature);
      setSelectedState(stateFeature);
      setSelectedCity(cityFeature);
      setSelectedStore(null);
      setView('city');
      setMapBounds(null);
      const coords = (cityFeature.geometry as GeoJSON.Point).coordinates;
      setMapCenter([coords[1], coords[0]]);
      setMapZoom(13);
      setPage(0);
    },
    []
  );

  const applyStoreNavigation = useCallback(
    (
      store: StoresMarker,
      countryFeature: GeoJSON.Feature,
      stateFeature: GeoJSON.Feature | null,
      cityFeature: GeoJSON.Feature | null
    ) => {
      setSelectedCountry(countryFeature);
      setSelectedState(stateFeature);
      setSelectedCity(cityFeature);
      setSelectedStore(store);
      setMapBounds(null);
      setMapCenter([store.lat, store.lng]);
      setMapZoom(15);
      setPage(0);
    },
    []
  );

  // ---------------------------------------------------------------------------
  // Async navigation resolution – filter → pending → resolved
  // ---------------------------------------------------------------------------
  const { clearResolvedRefs } = usePendingNavigation({
    pendingNavigation,
    setPendingNavigation,
    rawCountries,
    rawStates,
    isFetchingStates,
    rawCities,
    isFetchingCities,
    rawSites,
    isFetchingSites,
    setIsNoData,
    resetToWorldInternal,
    applyStateNavigation,
    applyCityNavigation,
    applyStoreNavigation,
  });

  // ---------------------------------------------------------------------------
  // External filter synchronisation – LocationSwitcher → map
  // ---------------------------------------------------------------------------
  useFilterSync({
    view,
    selectedCountry,
    selectedState,
    selectedCity,
    selectedStore,
    setPendingNavigation,
    applyCountryNavigation,
    setIsNoData,
    resetToWorldInternal,
    clearResolvedRefs,
  });

  const navigateToWorld = useCallback(() => {
    setIsNoData(false);
    resetToWorldInternal();
    selectLocation(null);
  }, [resetToWorldInternal, selectLocation]);

  const navigateToCountryOrStates = useCallback(() => {
    if (!selectedCountry) return;
    const isUSA =
      selectedCountry.properties?.ADM0_A3 === 'USA' || selectedCountry.properties?.ISO_A3 === 'USA';
    setSelectedCity(null);
    setSelectedState(null);
    setSelectedStore(null);
    setView(isUSA ? 'usa-states' : 'country');
    setMapBounds(null);
    const coords = (selectedCountry.geometry as GeoJSON.Point).coordinates;
    setMapCenter([coords[1], coords[0]]);
    setMapZoom(5);
    setPage(0);
    const displayName =
      selectedCountry.properties?.NAME || selectedCountry.properties?.ADM0_A3 || 'Country';
    const value = selectedCountry.properties?.ADM0_A3 || displayName;
    selectLocation({ displayName, value, level: isUSA ? 'State' : 'Country' });
  }, [selectedCountry, selectLocation]);

  const navigateToState = useCallback(() => {
    if (!selectedState) return;
    setSelectedCity(null);
    setSelectedStore(null);
    setView('country');
    setMapBounds(null);
    const coords = (selectedState.geometry as GeoJSON.Point).coordinates;
    setMapCenter([coords[1], coords[0]]);
    setMapZoom(7);
    setPage(0);
    const displayName =
      selectedState.properties?.name || selectedState.properties?.postal || 'State';
    const value = selectedState.properties?.postal || selectedState.properties?.name || displayName;
    selectLocation({ displayName, value, level: 'State' });
  }, [selectedState, selectLocation]);

  const handleCountrySelect = useCallback(
    (country: GeoJSON.Feature) => {
      const isUSA = country.properties?.ADM0_A3 === 'USA' || country.properties?.ISO_A3 === 'USA';
      setSelectedCountry(country);
      setSelectedState(null);
      setSelectedCity(null);
      setSelectedStore(null);
      setView(isUSA ? 'usa-states' : 'country');
      setMapBounds(null);
      const coords = (country.geometry as GeoJSON.Point).coordinates;
      setMapCenter([coords[1], coords[0]]);
      setMapZoom(5);
      setPage(0);
      const displayName = country.properties?.NAME || country.properties?.ADM0_A3 || 'Country';
      const value = country.properties?.ADM0_A3 || displayName;
      selectLocation({ displayName, value, level: 'Country' });
    },
    [selectLocation]
  );

  const handleStateSelect = useCallback(
    (state: GeoJSON.Feature) => {
      setSelectedState(state);
      setSelectedCity(null);
      setSelectedStore(null);
      setView('country');
      setMapBounds(null);
      const coords = (state.geometry as GeoJSON.Point).coordinates;
      setMapCenter([coords[1], coords[0]]);
      setMapZoom(7);
      setPage(0);
      const displayName = state.properties?.name || state.properties?.postal || 'State';
      const value = state.properties?.postal || state.properties?.name || displayName;
      selectLocation({ displayName, value, level: 'State' });
    },
    [selectLocation]
  );

  const handleCitySelect = useCallback(
    (city: GeoJSON.Feature) => {
      setSelectedCity(city);
      setSelectedStore(null);
      setView('city');
      setMapBounds(null);
      const coords = (city.geometry as GeoJSON.Point).coordinates;
      setMapCenter([coords[1], coords[0]]);
      setMapZoom(13);
      setPage(0);
      const displayName = city.properties?.NAME || 'City';
      selectLocation({ displayName, value: displayName, level: 'City' });
    },
    [selectLocation]
  );

  const handleStoreSelect = useCallback(
    (store: StoresMarker) => {
      setSelectedStore(store);
      setMapBounds(null);
      setMapCenter([store.lat, store.lng]);
      setMapZoom(15);
      setPage(0);
      selectLocation({ displayName: store.name, value: store.id, level: 'Store' });
    },
    [selectLocation]
  );

  // ---------------------------------------------------------------------------
  // Breadcrumbs (derived state, extracted to useBreadcrumbs)
  // ---------------------------------------------------------------------------
  const breadcrumbs = useBreadcrumbs({
    selectedCountry,
    selectedState,
    selectedCity,
    selectedStore,
    navigateToWorld,
    navigateToCountryOrStates,
    navigateToState,
    handleStoreSelect,
  });

  return {
    view,
    selectedCountry,
    selectedState,
    selectedCity,
    selectedStore,
    mapBounds,
    mapCenter,
    mapZoom,
    page,
    setPage,
    breadcrumbs,
    isNoData,
    handleCountrySelect,
    handleStateSelect,
    handleCitySelect,
    handleStoreSelect,
  };
};
