import { useCallback, useMemo } from 'react';
import { StoresMarker } from 'src/models';

export interface Breadcrumb {
  label: string;
  onClick?: () => void;
}

interface UseBreadcrumbsParams {
  selectedCountry: GeoJSON.Feature | null;
  selectedState: GeoJSON.Feature | null;
  selectedCity: GeoJSON.Feature | null;
  selectedStore: StoresMarker | null;
  navigateToWorld: () => void;
  navigateToCountryOrStates: () => void;
  navigateToState: () => void;
  handleStoreSelect: (store: StoresMarker) => void;
}

export const useBreadcrumbs = ({
  selectedCountry,
  selectedState,
  selectedCity,
  selectedStore,
  navigateToWorld,
  navigateToCountryOrStates,
  navigateToState,
  handleStoreSelect,
}: UseBreadcrumbsParams): Breadcrumb[] => {
  const handleStoreBreadcrumbClick = useCallback(() => {
    if (selectedStore && selectedCity) handleStoreSelect(selectedStore);
  }, [handleStoreSelect, selectedCity, selectedStore]);

  return useMemo(() => {
    const crumbs: Breadcrumb[] = [];
    const countryIsUSA =
      selectedCountry?.properties?.ADM0_A3 === 'USA' ||
      selectedCountry?.properties?.ISO_A3 === 'USA';

    crumbs.push({ label: 'World', onClick: navigateToWorld });

    if (selectedCountry) {
      const countryLabel = countryIsUSA
        ? 'United States'
        : selectedCountry.properties?.NAME || selectedCountry.properties?.ADM0_A3 || 'Country';
      crumbs.push({ label: countryLabel, onClick: navigateToCountryOrStates });
    }

    if (selectedState) {
      const stateLabel =
        selectedState.properties?.name || selectedState.properties?.postal || 'State';
      crumbs.push({ label: stateLabel, onClick: navigateToState });
    }

    if (selectedCity) {
      crumbs.push({ label: selectedCity.properties?.NAME || 'City' });
    }

    if (selectedStore) {
      crumbs.push({ label: selectedStore.name, onClick: handleStoreBreadcrumbClick });
    }

    return crumbs;
  }, [
    navigateToWorld,
    navigateToCountryOrStates,
    navigateToState,
    selectedCountry,
    selectedState,
    selectedCity,
    selectedStore,
    handleStoreBreadcrumbClick,
  ]);
};
