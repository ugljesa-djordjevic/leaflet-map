import { useEffect, useRef } from 'react';
import { useAppSelector } from 'src/store/hooks';
import { selectCurrentLocationFilter } from 'src/store/slices/dashboardFiltersSlice';
import { StoresMarker } from 'src/models';
import { MapView } from '../mapUtils';
import { IPendingNavigation } from './usePendingNavigation';

interface Params {
  view: MapView;
  selectedCountry: GeoJSON.Feature | null;
  selectedState: GeoJSON.Feature | null;
  selectedCity: GeoJSON.Feature | null;
  selectedStore: StoresMarker | null;
  setPendingNavigation: (nav: IPendingNavigation | null) => void;
  applyCountryNavigation: (code: string) => void;
  setIsNoData: (v: boolean) => void;
  resetToWorldInternal: () => void;
  clearResolvedRefs: () => void;
}

/**
 * Observes the Redux location filter and drives the map into the matching
 * navigation state. This is the bridge between the LocationSwitcher and the map.
 */
export const useFilterSync = ({
  view,
  selectedCountry,
  selectedState,
  selectedCity,
  selectedStore,
  setPendingNavigation,
  applyCountryNavigation,
  setIsNoData,
  resetToWorldInternal,
  clearResolvedRefs,
}: Params): void => {
  const filterLocation = useAppSelector(selectCurrentLocationFilter);
  const prevFilterRef = useRef<typeof filterLocation>(filterLocation);

  useEffect(() => {
    const prev = prevFilterRef.current;
    prevFilterRef.current = filterLocation;

    // No change — nothing to do
    if (filterLocation === prev) return;

    // Reset to world
    if (!filterLocation) {
      setIsNoData(false);
      if (view === 'world' && !selectedCountry) return;
      clearResolvedRefs();
      resetToWorldInternal();
      return;
    }

    const { level, value, countryCode, stateCode, cityName } = filterLocation;

    // Region is above Country — the map has no region concept; reset to world.
    if (level === 'Region') {
      setIsNoData(true);
      if (view === 'world' && !selectedCountry) return;
      clearResolvedRefs();
      resetToWorldInternal();
      return;
    }

    if (level === 'Country') {
      const alreadySelected =
        selectedCountry?.properties?.ADM0_A3 === value ||
        selectedCountry?.properties?.ISO_A3 === value;
      if (alreadySelected) return;
      applyCountryNavigation(value);
      return;
    }

    if (level === 'State') {
      if (selectedState?.properties?.postal === value) return;
      if (!countryCode) {
        if (import.meta.env.DEV)
          console.warn(
            `[LocationSwitcher→Map] Cannot navigate to State "${value}" — countryCode is missing. Rebuild & restart the backend. Resetting to world view.`
          );
        setIsNoData(true);
        resetToWorldInternal();
        return;
      }
      clearResolvedRefs();
      setPendingNavigation({ level: 'State', countryCode, stateCode: value });
      return;
    }

    if (level === 'City') {
      if (selectedCity?.properties?.NAME === value) return;
      if (!countryCode) {
        if (import.meta.env.DEV)
          console.warn(
            `[LocationSwitcher→Map] Cannot navigate to City "${value}" — countryCode is missing. Rebuild & restart the backend. Resetting to world view.`
          );
        setIsNoData(true);
        resetToWorldInternal();
        return;
      }
      clearResolvedRefs();
      setPendingNavigation({ level: 'City', countryCode, stateCode, cityName: value });
      return;
    }

    if (level === 'Store' || level === 'Store Nbr') {
      if (selectedStore?.id === value) return;
      if (!countryCode) {
        if (import.meta.env.DEV)
          console.warn(
            `[LocationSwitcher→Map] Cannot navigate to Store "${value}" — countryCode is missing. Rebuild & restart the backend. Resetting to world view.`
          );
        setIsNoData(true);
        resetToWorldInternal();
        return;
      }
      clearResolvedRefs();
      setPendingNavigation({ level: 'Store', countryCode, stateCode, cityName, storeValue: value });
      return;
    }

    if (import.meta.env.DEV)
      console.warn(
        `[LocationSwitcher→Map] Unhandled location level: "${level}" (value: "${value}"). Navigation not implemented for this level.`
      );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filterLocation]);
};
