import { ExploreOutlined } from '@mui/icons-material';
import { Box, Breadcrumbs, Link, Typography } from '@mui/material';

type BreadcrumbItem = {
  label: string;
  onClick?: () => void;
};

type Props = {
  breadcrumbs: BreadcrumbItem[];
};

export const LocationMapBreadcrumb = ({ breadcrumbs }: Props) => {
  const lastIndex = breadcrumbs.length - 1;

  return (
    <Box
      sx={{
        position: 'absolute',
        top: 16,
        left: 16,
        zIndex: 1000,
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        gap: '8px',
        px: 1,
        py: 0.5,
      }}
    >
      <ExploreOutlined sx={{ color: '#6B696D' }} />
      <Breadcrumbs separator='/' aria-label='location breadcrumbs'>
        {breadcrumbs.map((crumb, index) => {
          const isCurrent = index === lastIndex || !crumb.onClick;

          return isCurrent ? (
            <Typography key={crumb.label} variant='subtitle2' color='#6B696D'>
              {crumb.label}
            </Typography>
          ) : (
            <Link
              key={crumb.label}
              component='button'
              variant='subtitle2'
              underline='hover'
              color='#6B696D'
              onClick={crumb.onClick}
            >
              {crumb.label}
            </Link>
          );
        })}
      </Breadcrumbs>
    </Box>
  );
};
