import { LatLngExpression } from 'leaflet';
import MarkerClusterGroup from 'react-leaflet-cluster';
import { AvailabilityMarker } from '../AvailabilityMarker';
import { createClusterIcon, LABEL_THRESHOLD_BY_VIEW } from '../mapUtils';
import { useMapDataContext, useMapHoverContext } from '../MapContext';

export const USAStatesMarkersLayer = () => {
  const { usaStatesWithAvailability, currentZoom, onStateClick } = useMapDataContext();
  const { hoveredId, setHoveredId } = useMapHoverContext();

  return (
    <MarkerClusterGroup
      chunkedLoading
      showCoverageOnHover={false}
      spiderfyOnMaxZoom
      iconCreateFunction={createClusterIcon}
    >
      {usaStatesWithAvailability.map((state) => {
        const availability = state.properties?.availability ?? 0;
        const stateName = state.properties?.name || state.properties?.postal;
        const stateId = state.properties?.postal || stateName;
        const isHovered = hoveredId === stateId;
        const coords = (state.geometry as GeoJSON.Point).coordinates;
        const position: LatLngExpression = [coords[1], coords[0]];

        return (
          <AvailabilityMarker
            key={stateId}
            id={stateId}
            position={position}
            availability={availability}
            label={isHovered ? stateName : `${availability}%`}
            showLabel={isHovered || currentZoom >= LABEL_THRESHOLD_BY_VIEW['usa-states']}
            isHovered={isHovered}
            onClick={() => onStateClick(state)}
            onMouseEnter={() => setHoveredId(stateId)}
            onMouseLeave={() => setHoveredId(null)}
          />
        );
      })}
    </MarkerClusterGroup>
  );
};
