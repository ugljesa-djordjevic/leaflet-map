import { LatLngExpression } from 'leaflet';
import MarkerClusterGroup from 'react-leaflet-cluster';
import { AvailabilityMarker } from '../AvailabilityMarker';
import { createClusterIcon, LABEL_THRESHOLD_BY_VIEW } from '../mapUtils';
import { useMapContext } from '../MapContext';

export const USAStatesMarkersLayer = () => {
  const { usaStatesWithAvailability, hoveredId, setHoveredId, currentZoom, onStateClick } =
    useMapContext();

  return (
    <MarkerClusterGroup
      chunkedLoading
      showCoverageOnHover={false}
      spiderfyOnMaxZoom
      iconCreateFunction={createClusterIcon}
    >
      {usaStatesWithAvailability.map((state) => {
        const availability = state.properties?.availability ?? 0;
        const stateName = state.properties?.name || state.properties?.postal;
        const stateId = state.properties?.postal || stateName;
        const isHovered = hoveredId === stateId;
        const position: LatLngExpression = [
          state.properties?.latitude,
          state.properties?.longitude,
        ];

        return (
          <AvailabilityMarker
            key={stateId}
            id={stateId}
            position={position}
            availability={availability}
            label={isHovered ? stateName : `${availability}%`}
            showLabel={isHovered || currentZoom >= LABEL_THRESHOLD_BY_VIEW['usa-states']}
            isHovered={isHovered}
            onClick={() => onStateClick(state)}
            onMouseEnter={() => setHoveredId(stateId)}
            onMouseLeave={() => setHoveredId(null)}
          />
        );
      })}
    </MarkerClusterGroup>
  );
};
