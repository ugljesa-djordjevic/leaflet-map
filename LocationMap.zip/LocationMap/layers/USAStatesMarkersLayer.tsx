import { MarkersLayer } from './MarkersLayer';
import { useMapDataContext } from '../MapContext';

export const USAStatesMarkersLayer = () => {
  const { usaStates, onStateClick } = useMapDataContext();
  return <MarkersLayer markers={usaStates} view='usa-states' onSelect={onStateClick} />;
};
