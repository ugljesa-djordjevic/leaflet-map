import { useMemo } from 'react';
import L from 'leaflet';
import MarkerClusterGroup from 'react-leaflet-cluster';
import { AvailabilityMarker } from '../AvailabilityMarker';
import { createClusterIcon, LABEL_THRESHOLD_BY_VIEW } from '../mapUtils';
import { useMapDataContext, useMapHoverContext } from '../MapContext';

type Props = {
  viewportBounds: L.LatLngBounds | null;
};

export const CityMarkersLayer = ({ viewportBounds }: Props) => {
  const { storesForCity, currentZoom, onStoreClick } = useMapDataContext();
  const { hoveredId, setHoveredId } = useMapHoverContext();

  const visibleStores = useMemo(() => {
    if (!viewportBounds) return storesForCity;
    const padded = viewportBounds.pad(0.2);
    return storesForCity.filter((store) => padded.contains([store.lat, store.lng]));
  }, [storesForCity, viewportBounds]);

  return (
    <MarkerClusterGroup
      chunkedLoading
      showCoverageOnHover={false}
      spiderfyOnMaxZoom
      iconCreateFunction={createClusterIcon}
    >
      {visibleStores.map((store) => {
        const isHovered = hoveredId === store.id;

        return (
          <AvailabilityMarker
            key={store.id}
            id={store.id}
            position={[store.lat, store.lng]}
            availability={store.availability}
            label={isHovered ? store.name : `${store.availability}%`}
            showLabel={isHovered || currentZoom >= LABEL_THRESHOLD_BY_VIEW.city}
            isHovered={isHovered}
            onClick={() => onStoreClick(store)}
            onMouseEnter={() => setHoveredId(store.id)}
            onMouseLeave={() => setHoveredId(null)}
          />
        );
      })}
    </MarkerClusterGroup>
  );
};
