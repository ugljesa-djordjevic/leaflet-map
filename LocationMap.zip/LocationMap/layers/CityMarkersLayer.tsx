import L from 'leaflet';
import { MarkersLayer } from './MarkersLayer';
import { useMapDataContext } from '../MapContext';

type Props = {
  viewportBounds: L.LatLngBounds | null;
};

export const CityMarkersLayer = ({ viewportBounds }: Props) => {
  const { stores, onStoreClick } = useMapDataContext();
  return (
    <MarkersLayer
      markers={stores}
      view='city'
      onSelect={onStoreClick}
      viewportBounds={viewportBounds}
    />
  );
};
