import MarkerClusterGroup from 'react-leaflet-cluster';
import { AvailabilityMarker } from '../AvailabilityMarker';
import { createClusterIcon, LABEL_THRESHOLD_BY_VIEW } from '../mapUtils';
import { useMapContext } from '../MapContext';

export const CityMarkersLayer = () => {
  const { storesForCity, hoveredId, setHoveredId, currentZoom, onStoreClick } = useMapContext();

  return (
    <MarkerClusterGroup
      chunkedLoading
      showCoverageOnHover={false}
      spiderfyOnMaxZoom
      iconCreateFunction={createClusterIcon}
    >
      {storesForCity.map((store) => {
        const isHovered = hoveredId === store.id;

        return (
          <AvailabilityMarker
            key={store.id}
            id={store.id}
            position={[store.lat, store.lng]}
            availability={store.availability}
            label={isHovered ? store.name : `${store.availability}%`}
            showLabel={isHovered || currentZoom >= LABEL_THRESHOLD_BY_VIEW.city}
            isHovered={isHovered}
            onClick={() => onStoreClick(store)}
            onMouseEnter={() => setHoveredId(store.id)}
            onMouseLeave={() => setHoveredId(null)}
          />
        );
      })}
    </MarkerClusterGroup>
  );
};
