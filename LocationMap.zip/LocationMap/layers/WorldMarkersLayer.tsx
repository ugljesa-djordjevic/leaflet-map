import { MarkersLayer } from './MarkersLayer';
import { useMapDataContext } from '../MapContext';

export const WorldMarkersLayer = () => {
  const { countries, onCountryClick } = useMapDataContext();
  return <MarkersLayer markers={countries} view='world' onSelect={onCountryClick} />;
};
