import { LatLngExpression } from 'leaflet';
import MarkerClusterGroup from 'react-leaflet-cluster';
import { AvailabilityMarker } from '../AvailabilityMarker';
import { createClusterIcon, LABEL_THRESHOLD_BY_VIEW } from '../mapUtils';
import { useMapDataContext, useMapHoverContext } from '../MapContext';

export const WorldMarkersLayer = () => {
  const { countriesWithAvailability, currentZoom, onCountryClick } = useMapDataContext();
  const { hoveredId, setHoveredId } = useMapHoverContext();

  return (
    <MarkerClusterGroup
      chunkedLoading
      showCoverageOnHover={false}
      spiderfyOnMaxZoom
      iconCreateFunction={createClusterIcon}
    >
      {countriesWithAvailability.map((country) => {
        const availability = country.properties?.availability ?? 0;
        const countryId = country.properties?.ADM0_A3 || country.properties?.NAME;
        const isHovered = hoveredId === countryId;
        const coords = (country.geometry as GeoJSON.Point).coordinates;
        const position: LatLngExpression = [coords[1], coords[0]];

        return (
          <AvailabilityMarker
            key={countryId}
            id={countryId}
            position={position}
            availability={availability}
            label={isHovered ? country.properties?.NAME || countryId : `${availability}%`}
            showLabel={isHovered || currentZoom >= LABEL_THRESHOLD_BY_VIEW.world}
            isHovered={isHovered}
            onClick={() => onCountryClick(country)}
            onMouseEnter={() => setHoveredId(countryId)}
            onMouseLeave={() => setHoveredId(null)}
          />
        );
      })}
    </MarkerClusterGroup>
  );
};
