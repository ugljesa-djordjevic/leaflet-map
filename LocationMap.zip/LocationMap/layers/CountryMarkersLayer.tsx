import { useMemo } from 'react';
import L from 'leaflet';
import MarkerClusterGroup from 'react-leaflet-cluster';
import { AvailabilityMarker } from '../AvailabilityMarker';
import { createClusterIcon, LABEL_THRESHOLD_BY_VIEW } from '../mapUtils';
import { useMapDataContext, useMapHoverContext } from '../MapContext';
import { CityMarker } from 'src/models';

type Props = {
  viewportBounds: L.LatLngBounds | null;
};

export const CountryMarkersLayer = ({ viewportBounds }: Props) => {
  const { citiesForCountry, currentZoom, onCityClick } = useMapDataContext();
  const { hoveredId, setHoveredId } = useMapHoverContext();

  const cityMarkers = useMemo<CityMarker[]>(
    () =>
      citiesForCountry.map((city) => {
        const coords = (city.geometry as GeoJSON.Point).coordinates;
        return {
          id: `${city.properties?.ADM0_A3 || city.properties?.ADM0NAME}-${city.properties?.NAME}`,
          name: city.properties?.NAME,
          availability: city.properties?.availability ?? 0,
          lat: coords[1],
          lng: coords[0],
          feature: city,
        };
      }),
    [citiesForCountry]
  );

  const visibleMarkers = useMemo(() => {
    if (!viewportBounds) return cityMarkers;
    const padded = viewportBounds.pad(0.2);
    return cityMarkers.filter((city) => padded.contains([city.lat, city.lng]));
  }, [cityMarkers, viewportBounds]);

  return (
    <MarkerClusterGroup
      chunkedLoading
      showCoverageOnHover={false}
      spiderfyOnMaxZoom
      iconCreateFunction={createClusterIcon}
    >
      {visibleMarkers.map((city) => {
        const isHovered = hoveredId === city.id;

        return (
          <AvailabilityMarker
            key={city.id}
            id={city.id}
            position={[city.lat, city.lng]}
            availability={city.availability}
            label={isHovered ? city.name : `${city.availability}%`}
            showLabel={isHovered || currentZoom >= LABEL_THRESHOLD_BY_VIEW.country}
            isHovered={isHovered}
            onClick={() => onCityClick(city.feature)}
            onMouseEnter={() => setHoveredId(city.id)}
            onMouseLeave={() => setHoveredId(null)}
          />
        );
      })}
    </MarkerClusterGroup>
  );
};
