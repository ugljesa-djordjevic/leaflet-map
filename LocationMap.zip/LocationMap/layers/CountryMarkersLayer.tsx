import L from 'leaflet';
import { MarkersLayer } from './MarkersLayer';
import { useMapDataContext } from '../MapContext';

type Props = {
  viewportBounds: L.LatLngBounds | null;
};

export const CountryMarkersLayer = ({ viewportBounds }: Props) => {
  const { cities, onCityClick } = useMapDataContext();
  return (
    <MarkersLayer
      markers={cities}
      view='country'
      onSelect={onCityClick}
      viewportBounds={viewportBounds}
    />
  );
};
