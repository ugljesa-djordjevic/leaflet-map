import { useCallback, useMemo } from 'react';
import L from 'leaflet';
import MarkerClusterGroup from 'react-leaflet-cluster';
import { useTheme } from '@mui/material';
import { AvailabilityMarker } from '../AvailabilityMarker';
import { makeClusterIcon } from '../mapUtils';
import { getAvailabilityColor } from '../availability';
import { LABEL_ZOOM_BY_VIEW, VIEWPORT_PAD } from '../mapConstants';
import { useMapDataContext, useMapHoverContext } from '../MapContext';
import { AvailabilityPoint, MapView } from '../types';

type Props<T extends AvailabilityPoint> = {
  markers: T[];
  /** Drives the zoom level at which labels become permanently visible. */
  view: MapView;
  onSelect: (marker: T) => void;
  /** When provided, off-screen markers are culled (used for the dense city/store sets). */
  viewportBounds?: L.LatLngBounds | null;
};

/**
 * Renders a clustered set of availability markers for any navigation level.
 * The four levels (world / usa-states / country / city) differ only in their
 * data and click handler, so they share this single implementation.
 */
export const MarkersLayer = <T extends AvailabilityPoint>({
  markers,
  view,
  onSelect,
  viewportBounds,
}: Props<T>) => {
  const theme = useTheme();
  const { currentZoom } = useMapDataContext();
  const { hoveredId, setHoveredId } = useMapHoverContext();

  const labelZoom = LABEL_ZOOM_BY_VIEW[view];

  const visibleMarkers = useMemo(() => {
    if (!viewportBounds) return markers;
    const padded = viewportBounds.pad(VIEWPORT_PAD);
    return markers.filter((m) => padded.contains([m.lat, m.lng]));
  }, [markers, viewportBounds]);

  const markersById = useMemo(() => new Map(markers.map((m) => [m.id, m])), [markers]);
  const handleSelect = useCallback(
    (id: string) => {
      const marker = markersById.get(id);
      if (marker) onSelect(marker);
    },
    [markersById, onSelect]
  );

  const clusterIcon = useMemo(
    () => makeClusterIcon((value) => getAvailabilityColor(theme, value)),
    [theme]
  );

  return (
    <MarkerClusterGroup
      chunkedLoading
      showCoverageOnHover={false}
      spiderfyOnMaxZoom
      iconCreateFunction={clusterIcon}
    >
      {visibleMarkers.map((marker) => {
        const isHovered = hoveredId === marker.id;
        return (
          <AvailabilityMarker
            key={marker.id}
            id={marker.id}
            lat={marker.lat}
            lng={marker.lng}
            availability={marker.availability}
            label={isHovered ? marker.name : `${marker.availability}%`}
            showLabel={isHovered || currentZoom >= labelZoom}
            isHovered={isHovered}
            onSelect={handleSelect}
            onHover={setHoveredId}
          />
        );
      })}
    </MarkerClusterGroup>
  );
};
