import { memo, useCallback, useMemo } from 'react';
import { LatLngExpression } from 'leaflet';
import { Marker, Tooltip } from 'react-leaflet';
import { Typography, useTheme } from '@mui/material';
import { createMarkerIcon } from './mapUtils';
import { HOVER_MARKER_COLOR } from './availability';
import { ColorUtils } from 'src/utils/ColorUtils';

type Props = {
  id: string;
  lat: number;
  lng: number;
  availability: number;
  label: string;
  showLabel: boolean;
  isHovered: boolean;
  onSelect: (id: string) => void;
  onHover: (id: string | null) => void;
};

const AvailabilityMarkerBase = ({
  id,
  lat,
  lng,
  availability,
  label,
  showLabel,
  isHovered,
  onSelect,
  onHover,
}: Props) => {
  const theme = useTheme();
  const fill = isHovered ? HOVER_MARKER_COLOR : ColorUtils.getProgressColor(theme, availability);
  const icon = useMemo(() => createMarkerIcon({ fill, isHovered }), [fill, isHovered]);
  const position = useMemo<LatLngExpression>(() => [lat, lng], [lat, lng]);

  const handleClick = useCallback(() => onSelect(id), [onSelect, id]);
  const handleMouseOver = useCallback(() => onHover(id), [onHover, id]);
  const handleMouseOut = useCallback(() => onHover(null), [onHover]);

  return (
    <Marker
      // Stash availability on the Leaflet marker so the cluster icon can average it.
      ref={(marker) => {
        if (marker) (marker.options as { availability?: number }).availability = availability;
      }}
      position={position}
      icon={icon}
      eventHandlers={{ click: handleClick, mouseover: handleMouseOver, mouseout: handleMouseOut }}
    >
      {showLabel && (
        <Tooltip permanent direction='center' className='availability-tooltip'>
          <Typography sx={{ color: 'common.white', fontWeight: 500, fontSize: '10px' }}>
            {label}
          </Typography>
        </Tooltip>
      )}
    </Marker>
  );
};

export const AvailabilityMarker = memo(AvailabilityMarkerBase);
