import { useMemo } from 'react';
import { LatLngExpression } from 'leaflet';
import { Marker, Tooltip } from 'react-leaflet';
import { HOVER_COLOR, createMarkerIcon, getMarkerColor } from './mapUtils';
import { Typography } from '@mui/material';

type Props = {
  id: string;
  position: LatLngExpression;
  availability: number;
  label: string;
  showLabel: boolean;
  isHovered: boolean;
  onClick: () => void;
  onMouseEnter: () => void;
  onMouseLeave: () => void;
};

export const AvailabilityMarker = ({
  id,
  position,
  availability,
  label,
  showLabel,
  isHovered,
  onClick,
  onMouseEnter,
  onMouseLeave,
}: Props) => {
  const fill = isHovered ? HOVER_COLOR : getMarkerColor(availability);
  const icon = useMemo(() => createMarkerIcon({ fill, isHovered }), [fill, isHovered]);

  return (
    <Marker
      ref={(marker) => {
        if (marker) (marker.options as { availability?: number }).availability = availability;
      }}
      key={id}
      position={position}
      icon={icon}
      eventHandlers={{
        click: onClick,
        mouseover: onMouseEnter,
        mouseout: onMouseLeave,
      }}
    >
      {showLabel && (
        <Tooltip permanent direction='center' className='availability-tooltip'>
          <Typography style={{ color: '#FFF', fontWeight: 500, fontSize: '10px' }}>
            {label}
          </Typography>
        </Tooltip>
      )}
    </Marker>
  );
};
